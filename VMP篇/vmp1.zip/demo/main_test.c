#include <stdio.h> // printf
#include <stdlib.h> // malloc/free
#include <string.h> // memcpy
#include <stdint.h> // uint64_t, uint8_t等类型
#include <time.h> // time
#include "vmp/state.h" // VMState等定义
#include "vmp/encrypt.h" // lvmp_encrypt

// 动态数组（教学用简单版本）
typedef struct {
    uint32_t* v; // 数据缓冲
    int n, cap; // 当前大小和容量
} Vec;

// 初始化动态数组
static void vinit(Vec* vec) {
    vec->v = NULL;
    vec->n = 0;
    vec->cap = 0;
}

// 向动态数组追加元素
static void vpush(Vec* vec, uint32_t val) {
    if (vec->n >= vec->cap) {
        vec->cap = vec->cap ? vec->cap * 2 : 16;
        vec->v = (uint32_t*)realloc(vec->v, vec->cap * sizeof(uint32_t));
    }
    vec->v[vec->n++] = val;
}

// 宿主函数指针类型
typedef long long (*vmp_thunk_t)(const uint64_t* regs);

// 外部函数声明
long long lvmp_entry(const uint8_t* blob, int blob_len, 
                     const uint64_t* args, int nargs,
                     vmp_thunk_t* thunks, int nthunks,
                     uint64_t func_key, uint64_t runtime_tweak);

// 构建简单测试：只返回第一个参数
void build_return_first(Vec* out) {
    vinit(out);
    // 简单返回 v0（第一个参数）
    vpush(out, ENC_RRR(OP_RET, 0,0,0)); // RET
}

// 构建简单加法测试：返回两个参数的和
void build_add_two(Vec* out) {
    vinit(out);
    // v2 = v0 + v1
    vpush(out, ENC_RRR(OP_ADD, 2, 0, 1)); // v2 = v0 + v1
    vpush(out, ENC_RRR(OP_MOVrr, 0, 2, 31)); // v0 = v2
    vpush(out, ENC_RRR(OP_RET, 0,0,0)); // RET
}

// 构建计数循环测试：计算0到n-1的和
void build_count_sum(Vec* out) {
    vinit(out);
    
    // 初始化：v2=sum=0, v3=i=0
    vpush(out, ENC_RI(OP_ADDI, 2, 31, 0)); // v2 = 0 (sum)
    vpush(out, ENC_RI(OP_ADDI, 3, 31, 0)); // v3 = 0 (i)
    
    int loop_start = out->n; // 循环开始位置
    
    // 比较 i 和 n (v1)
    vpush(out, ENC_RRR(OP_CMPrr, 0, 3, 1)); // CMP v3, v1
    int bcc_pos = out->n;
    vpush(out, ENC_BR(OP_BCC, 0) | (2u<<19)); // BCC GE（如果i>=n则跳出）
    
    // 循环体：sum += i, i++
    vpush(out, ENC_RRR(OP_ADD, 2, 2, 3)); // v2 += v3 (sum += i)
    vpush(out, ENC_RI(OP_ADDI, 3, 3, 1)); // v3++ (i++)
    
    // 跳回循环开始
    vpush(out, ENC_BR(OP_B, loop_start - out->n)); // B loop_start
    
    int exit_pos = out->n;
    
    // 回填分支偏移
    int bcc_offset = exit_pos - bcc_pos;
    out->v[bcc_pos] = (out->v[bcc_pos] & 0xFFE00000) | (bcc_offset & 0x1FFFFF);
    
    // 返回结果
    vpush(out, ENC_RRR(OP_MOVrr, 0, 2, 31)); // v0 = v2
    vpush(out, ENC_RRR(OP_RET, 0,0,0)); // RET
}

// 构建立即数测试：返回一个固定值
void build_return_const(Vec* out, int value) {
    vinit(out);
    // 加载立即数到v2
    vpush(out, ENC_RI(OP_ADDI, 2, 31, value)); // v2 = 0 + value
    vpush(out, ENC_RRR(OP_MOVrr, 0, 2, 31)); // v0 = v2
    vpush(out, ENC_RRR(OP_RET, 0,0,0)); // RET
}

// 构建乘法表测试：生成并打印99乘法表
// 由于VM没有直接的打印功能，我们通过宿主函数来实现
// 这里我们构建一个简单的乘法函数来验证乘法运算
void build_multiplication_table(Vec* out) {
    vinit(out);
    
    // 计算 9 * 9 = 81
    // 使用重复加法实现乘法: 9*9 = 9 + 9 + ... + 9 (9次)
    
    // v2 = 9 (被乘数)
    vpush(out, ENC_RI(OP_ADDI, 2, 31, 9)); // v2 = 9
    
    // v3 = 9 (乘数)
    vpush(out, ENC_RI(OP_ADDI, 3, 31, 9)); // v3 = 9
    
    // v4 = 0 (结果)
    vpush(out, ENC_RI(OP_ADDI, 4, 31, 0)); // v4 = 0
    
    // v5 = 0 (计数器)
    vpush(out, ENC_RI(OP_ADDI, 5, 31, 0)); // v5 = 0
    
    int loop_start = out->n;
    
    // 检查计数器是否小于乘数
    vpush(out, ENC_RRR(OP_CMPrr, 0, 5, 3)); // CMP v5, v3 (计数器, 乘数)
    int bcc_pos = out->n;
    vpush(out, ENC_BR(OP_BCC, 0) | (3u<<19)); // BCC LT (如果计数器<乘数则继续)
    
    // 执行加法: 结果 += 被乘数
    vpush(out, ENC_RRR(OP_ADD, 4, 4, 2)); // v4 += v2 (结果 += 被乘数)
    
    // 计数器++
    vpush(out, ENC_RI(OP_ADDI, 5, 5, 1)); // v5++ (计数器++)
    
    // 跳回循环开始
    vpush(out, ENC_BR(OP_B, loop_start - out->n)); // B loop_start
    
    // 循环结束
    int loop_exit = out->n;
    
    // 回填分支偏移
    int bcc_offset = loop_exit - bcc_pos;
    out->v[bcc_pos] = (out->v[bcc_pos] & 0xFFE00000) | (bcc_offset & 0x1FFFFF);
    
    // 返回结果 (9*9=81)
    vpush(out, ENC_RRR(OP_MOVrr, 0, 4, 31)); // v0 = v4 (乘积结果)
    vpush(out, ENC_RRR(OP_RET, 0,0,0)); // RET
}

// 运行测试用例
long long run_test(const char* test_name, Vec* bytecode, const uint64_t* args, int nargs, long long expected) {
    printf("\n=== %s ===\n", test_name);
    
    // 组装 blob
    vmp_bc_header_t hdr;
    memcpy(hdr.magic,"LVMP",4);
    hdr.version=1;
    hdr.flags=0; // 关闭 trace
    hdr.reserved=0;
    hdr.code_words=bytecode->n;
    
    printf("字节码长度: %d 条指令\n", bytecode->n);
    printf("字节码内容: ");
    for(int i = 0; i < bytecode->n; i++) {
        printf("0x%08x ", bytecode->v[i]);
    }
    printf("\n");
    
    int blob_len = (int)sizeof(hdr) + bytecode->n*4;
    uint8_t* blob = (uint8_t*)malloc(blob_len);
    memcpy(blob, &hdr, sizeof(hdr));
    memcpy(blob+sizeof(hdr), bytecode->v, bytecode->n*4);
    
    // 加密
    uint64_t key=0xBADC0FFEE0DDF00Dull;
    uint64_t tweak=(uint64_t)time(NULL);
    lvmp_encrypt(blob+sizeof(hdr), bytecode->n*4, key, tweak);
    
    // 调用VM
    long long result = lvmp_entry(blob, blob_len, args, nargs, NULL, 0, key, tweak);
    
    // 输出结果
    printf("参数: ");
    for(int i = 0; i < nargs; i++) {
        printf("v%d=%llu ", i, args[i]);
    }
    printf("\n");
    printf("结果: %lld, 期望: %lld, ", result, expected);
    if(result == expected) {
        printf("✓ 通过\n");
    } else {
        printf("✗ 失败\n");
    }
    
    free(blob);
    return result;
}

int main(){
    // 设置Windows控制台代码页为UTF-8，解决中文乱码问题
    #ifdef _WIN32
    system("chcp 65001 > nul");
    #endif
    
    printf("=== VMP (虚拟机保护) 测试套件 ===\n");
    printf("Windows 11 + GCC 环境测试\n");
    
    int passed = 0, total = 0;
    
    // 测试1：简单返回测试
    {
        printf("\n>>> 测试1：返回第一个参数\n");
        Vec bc;
        build_return_first(&bc);
        uint64_t args[] = {42};
        total++;
        if(run_test("返回第一个参数", &bc, args, 1, 42) == 42) passed++;
        free(bc.v);
    }
    
    // 测试2：立即数测试
    {
        printf("\n>>> 测试2：返回固定常数\n");
        Vec bc;
        build_return_const(&bc, 100);
        uint64_t args[] = {0}; // 参数无关紧要
        total++;
        if(run_test("返回常数100", &bc, args, 1, 100) == 100) passed++;
        free(bc.v);
    }
    
    // 测试3：简单加法测试
    {
        printf("\n>>> 测试3：两数相加\n");
        Vec bc;
        build_add_two(&bc);
        uint64_t args[] = {15, 27};
        total++;
        if(run_test("两数相加", &bc, args, 2, 42) == 42) passed++;
        free(bc.v);
    }
    
    // 测试4：计数求和测试
    {
        printf("\n>>> 测试4：计数求和 (0到4)\n");
        Vec bc;
        build_count_sum(&bc);
        uint64_t args[] = {0, 5}; // 计算0+1+2+3+4 = 10
        total++;
        if(run_test("计数求和 (0到4)", &bc, args, 2, 10) == 10) passed++;
        free(bc.v);
    }
    
    // 测试5：更大的计数求和
    {
        printf("\n>>> 测试5：计数求和 (0到9)\n");
        Vec bc;
        build_count_sum(&bc);
        uint64_t args[] = {0, 10}; // 计算0+1+2+...+9 = 45
        total++;
        if(run_test("计数求和 (0到9)", &bc, args, 2, 45) == 45) passed++;
        free(bc.v);
    }
    
    // 测试6：边界条件测试
    {
        printf("\n>>> 测试6：边界条件 (空循环)\n");
        Vec bc;
        build_count_sum(&bc);
        uint64_t args[] = {0, 0}; // n=0，应该返回0
        total++;
        if(run_test("空循环", &bc, args, 2, 0) == 0) passed++;
        free(bc.v);
    }
    
    // 测试7：99乘法表测试
    {
        printf("\n>>> 测试7：99乘法表计算测试\n");
        Vec bc;
        build_multiplication_table(&bc);
        uint64_t args[] = {0}; // 参数无关紧要
        total++;
        // 期望结果是9*9=81（最后一个乘积）
        if(run_test("99乘法表", &bc, args, 1, 81) == 81) passed++;
        free(bc.v);
    }
    
    // 总结
    printf("\n=== 测试总结 ===\n");
    printf("通过: %d/%d\n", passed, total);
    printf("成功率: %.1f%%\n", (double)passed / total * 100);
    
    if(passed == total) {
        printf("🎉 所有测试通过！VMP系统基本功能正常。\n");
        printf("✓ 指令解码正确\n");
        printf("✓ 算术运算正确\n");
        printf("✓ 控制流正确\n");
        printf("✓ 分支跳转正确\n");
        printf("✓ 寄存器操作正确\n");
        return 0;
    } else {
        printf("⚠️ 部分测试失败，需要进一步调试。\n");
        return 1;
    }
}