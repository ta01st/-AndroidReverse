#include <stdio.h> // printf
#include <stdlib.h> // malloc/free
#include <string.h> // memcpy
#include <stdint.h> // uint64_t, uint8_t等类型
#include <time.h> // time
#include "vmp/state.h" // VMState等定义
#include "vmp/encrypt.h" // lvmp_encrypt

// 动态数组（教学用简单版本）
typedef struct {
    uint32_t* v; // 数据缓冲
    int n, cap; // 当前大小和容量
} Vec;

// 初始化动态数组
static void vinit(Vec* vec) {
    vec->v = NULL;
    vec->n = 0;
    vec->cap = 0;
}

// 向动态数组追加元素
static void vpush(Vec* vec, uint32_t val) {
    if (vec->n >= vec->cap) {
        vec->cap = vec->cap ? vec->cap * 2 : 16;
        vec->v = (uint32_t*)realloc(vec->v, vec->cap * sizeof(uint32_t));
    }
    vec->v[vec->n++] = val;
}

// 宿主函数指针类型
typedef long long (*vmp_thunk_t)(const uint64_t* regs);

// 外部函数声明
long long lvmp_entry(const uint8_t* blob, int blob_len, 
                     const uint64_t* args, int nargs,
                     vmp_thunk_t* thunks, int nthunks,
                     uint64_t func_key, uint64_t runtime_tweak);
void build_sum64(Vec* out);

// 构建求和函数的字节码
void build_sum64(Vec* out) {
    vinit(out); // 初始化向量
    
    // 函数参数：v0=p(数组指针), v1=n(元素个数)
    // 局部变量：v2=sum, v3=i
    
    // 初始化：v2=0; v3=0
    vpush(out, ENC_RI(OP_ADDI,2,31,0)); // v2 = 0 + 0 (sum)
    vpush(out, ENC_RI(OP_ADDI,3,31,0)); // v3 = 0 + 0 (i)
    
    int loop = out->n; // 记录循环入口, 应该是 2
    
    // if (i >= n) goto exit —— 有符号比较：GE（N==V）
    vpush(out, ENC_RRR(OP_CMPrr,0,3,1)); // CMP v3, v1（更新 NZCV）
    int at_bcc = out->n; // 记录 BCC 的位置，应该是 3
    vpush(out, ENC_BR(OP_BCC, 0)); // 先占位：OP_BCC + off=0
    out->v[at_bcc] |= (2u<<19); // 把 cond=GE(signed)=2 写入 rd 字段高 4 位
    
    // 计算地址与加载：v4=3; v5=i<<3; v6=p+v5; v7=[v6]
    vpush(out, ENC_RRR(OP_LIMM,4,0,0)); // LIMM v4, 3  pc=4
    vpush(out, 0);                      // low word     pc=5 
    vpush(out, 3);                      // high word    pc=6
    vpush(out, ENC_RRR(OP_LSL, 5,3,4)); // v5 = v3 << v4 （i<<3）  pc=7
    vpush(out, ENC_RRR(OP_ADD, 6,0,5)); // v6 = v0 + v5 （p + i*8） pc=8
    vpush(out, ENC_MEM(OP_LDRX,7,6,0)); // v7 = [v6]    pc=9
    
    // 累加并递增 i
    vpush(out, ENC_RRR(OP_ADD, 2,2,7)); // v2 += v7      pc=10
    vpush(out, ENC_RI (OP_ADDI,3,3,1)); // v3 += 1       pc=11
    
    // 无条件回跳到 loop（注意：分支位移单位是"指令数"，允许负数）
    vpush(out, ENC_BR(OP_B, loop - out->n)); // off = loop - current_pc
    
    int exit = out->n; // 记录 exit 入口 PC, 应该是 13
    
    // 回填前面的 BCC 偏移，使其跳到 exit
    int bcc_offset = exit - at_bcc; // 从 BCC 指令位置到 exit 的偏移
    // 保留条件码，更新偏移量
    out->v[at_bcc] = (out->v[at_bcc] & 0xFFE00000) | (bcc_offset & 0x1FFFFF);
    
    // return sum（把 v2 移到 v0，再 RET）
    vpush(out, ENC_RRR(OP_MOVrr,0,2,31)); // v0 = v2      pc=13
    vpush(out, ENC_RRR(OP_RET, 0,0,0)); // RET           pc=14
}


int main(){
// —— 准备被累加的数据 ——
long long arr[] = {10, 20, -5, 7, 100, 3}; // 示例数组
int n = (int)(sizeof(arr)/sizeof(arr[0])); // 元素个数
long long expect=0; for (int i=0;i<n;i++) expect += arr[i]; // 计算期望值


// —— 构造指令数组 ——
Vec bc; build_sum64(&bc); // 生成字节码


// —— 组装 blob = [头部][代码区] ——
vmp_bc_header_t hdr; // 准备头部
memcpy(hdr.magic,"LVMP",4); // 填魔数（教学特征）
hdr.version=1; // 版本 1
hdr.flags=0; // 关闭 trace
hdr.reserved=0; // 预留位清零
hdr.code_words=bc.n; // 指令数


int blob_len = (int)sizeof(hdr) + bc.n*4; // 总长度 = 头部 + 代码区
uint8_t* blob = (uint8_t*)malloc(blob_len); // 申请 blob 缓冲
memcpy(blob, &hdr, sizeof(hdr)); // 复制头部
memcpy(blob+sizeof(hdr), bc.v, bc.n*4); // 复制明文代码区


// —— 加密“代码区”（头部保持明文，便于教学识别） ——
uint64_t key=0xBADC0FFEE0DDF00Dull; // 教学用 key（示例）
uint64_t tweak=(uint64_t)time(NULL); // 运行时扰动（示例）
lvmp_encrypt(blob+sizeof(hdr), bc.n*4, key, tweak); // 代码区转为密文


// —— 准备 VM 实参（v0=p, v1=n）并调用解释器 ——
uint64_t args[2] = { (uint64_t)(uintptr_t)arr, (uint64_t)n };
long long ret = lvmp_entry(blob, blob_len, args, 2,
NULL, 0, key, tweak);


// —— 打印结果并清理 ——
printf("VM ret=%lld, expect=%lld\n", ret, expect);
free(bc.v); free(blob); // 释放内存
return 0; // 正常结束
}