#include <stdio.h> // printf
#include <stdlib.h> // malloc/free
#include <string.h> // memcpy
#include <stdint.h> // uint64_t, uint8_t等类型
#include <time.h> // time
#include "vmp/state.h" // VMState等定义
#include "vmp/encrypt.h" // lvmp_encrypt

// 动态数组（教学用简单版本）
typedef struct {
    uint32_t* v; // 数据缓冲
    int n, cap; // 当前大小和容量
} Vec;

// 初始化动态数组
static void vinit(Vec* vec) {
    vec->v = NULL;
    vec->n = 0;
    vec->cap = 0;
}

// 向动态数组追加元素
static void vpush(Vec* vec, uint32_t val) {
    if (vec->n >= vec->cap) {
        vec->cap = vec->cap ? vec->cap * 2 : 16;
        vec->v = (uint32_t*)realloc(vec->v, vec->cap * sizeof(uint32_t));
    }
    vec->v[vec->n++] = val;
}

// 宿主函数指针类型
typedef long long (*vmp_thunk_t)(const uint64_t* regs);

// 外部函数声明
long long lvmp_entry(const uint8_t* blob, int blob_len, 
                     const uint64_t* args, int nargs,
                     vmp_thunk_t* thunks, int nthunks,
                     uint64_t func_key, uint64_t runtime_tweak);

// 宿主函数：打印乘法表项
long long print_multiplication_item(const uint64_t* regs) {
    int i = (int)regs[0];  // 第一个操作数
    int j = (int)regs[1];  // 第二个操作数
    int result = (int)regs[2];  // 乘积结果
    printf("%d*%d=%-3d ", i, j, result);
    return 0;
}

// 构建简单的乘法表字节码（只计算并打印几项）
void build_simple_multiplication_table(Vec* out) {
    vinit(out);
    
    // 计算 2 * 3 = 6
    // 使用重复加法实现乘法: 2*3 = 2 + 2 + 2
    
    // v2 = 2 (被乘数)
    vpush(out, ENC_RI(OP_ADDI, 2, 31, 2)); // v2 = 2
    
    // v3 = 3 (乘数)
    vpush(out, ENC_RI(OP_ADDI, 3, 31, 3)); // v3 = 3
    
    // v4 = 0 (结果)
    vpush(out, ENC_RI(OP_ADDI, 4, 31, 0)); // v4 = 0
    
    // v5 = 0 (计数器)
    vpush(out, ENC_RI(OP_ADDI, 5, 31, 0)); // v5 = 0
    
    int loop_start = out->n;
    
    // 检查计数器是否小于乘数
    vpush(out, ENC_RRR(OP_CMPrr, 0, 5, 3)); // CMP v5, v3 (计数器, 乘数)
    int bcc_pos = out->n;
    vpush(out, ENC_BR(OP_BCC, 0) | (3u<<19)); // BCC LT (如果计数器<乘数则继续)
    
    // 执行加法: 结果 += 被乘数
    vpush(out, ENC_RRR(OP_ADD, 4, 4, 2)); // v4 += v2 (结果 += 被乘数)
    
    // 计数器++
    vpush(out, ENC_RI(OP_ADDI, 5, 5, 1)); // v5++ (计数器++)
    
    // 跳回循环开始
    vpush(out, ENC_BR(OP_B, loop_start - out->n)); // B loop_start
    
    // 循环结束
    int loop_exit = out->n;
    
    // 回填分支偏移
    int bcc_offset = loop_exit - bcc_pos;
    out->v[bcc_pos] = (out->v[bcc_pos] & 0xFFE00000) | (bcc_offset & 0x1FFFFF);
    
    // 调用宿主函数打印结果: 2*3=6
    vpush(out, ENC_RI(OP_ADDI, 0, 31, 2)); // v0 = 2
    vpush(out, ENC_RI(OP_ADDI, 1, 31, 3)); // v1 = 3
    vpush(out, ENC_RI(OP_ADDI, 2, 31, 6)); // v2 = 6
    vpush(out, ENC_BR(OP_BL, 0)); // 调用宿主函数，索引0
    
    // 再计算 4 * 5 = 20
    // v2 = 4 (被乘数)
    vpush(out, ENC_RI(OP_ADDI, 2, 31, 4)); // v2 = 4
    
    // v3 = 5 (乘数)
    vpush(out, ENC_RI(OP_ADDI, 3, 31, 5)); // v3 = 5
    
    // v4 = 0 (结果)
    vpush(out, ENC_RI(OP_ADDI, 4, 31, 0)); // v4 = 0
    
    // v5 = 0 (计数器)
    vpush(out, ENC_RI(OP_ADDI, 5, 31, 0)); // v5 = 0
    
    int loop_start2 = out->n;
    
    // 检查计数器是否小于乘数
    vpush(out, ENC_RRR(OP_CMPrr, 0, 5, 3)); // CMP v5, v3 (计数器, 乘数)
    int bcc_pos2 = out->n;
    vpush(out, ENC_BR(OP_BCC, 0) | (3u<<19)); // BCC LT (如果计数器<乘数则继续)
    
    // 执行加法: 结果 += 被乘数
    vpush(out, ENC_RRR(OP_ADD, 4, 4, 2)); // v4 += v2 (结果 += 被乘数)
    
    // 计数器++
    vpush(out, ENC_RI(OP_ADDI, 5, 5, 1)); // v5++ (计数器++)
    
    // 跳回循环开始
    vpush(out, ENC_BR(OP_B, loop_start2 - out->n)); // B loop_start2
    
    // 循环结束
    int loop_exit2 = out->n;
    
    // 回填分支偏移
    int bcc_offset2 = loop_exit2 - bcc_pos2;
    out->v[bcc_pos2] = (out->v[bcc_pos2] & 0xFFE00000) | (bcc_offset2 & 0x1FFFFF);
    
    // 调用宿主函数打印结果: 4*5=20
    vpush(out, ENC_RI(OP_ADDI, 0, 31, 4)); // v0 = 4
    vpush(out, ENC_RI(OP_ADDI, 1, 31, 5)); // v1 = 5
    vpush(out, ENC_RI(OP_ADDI, 2, 31, 20)); // v2 = 20
    vpush(out, ENC_BR(OP_BL, 0)); // 调用宿主函数，索引0
    
    // 返回
    vpush(out, ENC_RRR(OP_MOVrr, 0, 31, 31)); // v0 = 0
    vpush(out, ENC_RRR(OP_RET, 0,0,0)); // RET
}

// 构建完整的99乘法表字节码
void build_full_multiplication_table(Vec* out) {
    vinit(out);
    
    // 外层循环 i 从 1 到 9
    // v2 = i (外层循环变量)
    vpush(out, ENC_RI(OP_ADDI, 2, 31, 1)); // v2 = 1 (i)
    
    int outer_loop = out->n;
    
    // 检查 i <= 9
    vpush(out, ENC_RI(OP_ADDI, 3, 31, 9)); // v3 = 9
    vpush(out, ENC_RRR(OP_CMPrr, 0, 2, 3)); // CMP v2, v3 (i, 9)
    int outer_bcc_pos = out->n;
    vpush(out, ENC_BR(OP_BCC, 0) | (3u<<19)); // BCC LT (如果i<9则继续，如果i>=9则跳出到程序结束)
    
    // 内层循环 j 从 1 到 i
    // v4 = j (内层循环变量)
    vpush(out, ENC_RI(OP_ADDI, 4, 31, 1)); // v4 = 1 (j)
    
    int inner_loop = out->n;
    
    // 检查 j <= i
    vpush(out, ENC_RRR(OP_CMPrr, 0, 4, 2)); // CMP v4, v2 (j, i)
    int inner_bcc_pos = out->n;
    vpush(out, ENC_BR(OP_BCC, 0) | (3u<<19)); // BCC LT (如果j<i则继续，如果j>=i则跳出到换行)
    
    // 计算 i * j (使用重复加法)
    // v5 = 0 (乘积结果)
    vpush(out, ENC_RI(OP_ADDI, 5, 31, 0)); // v5 = 0
    
    // v6 = 0 (加法计数器)
    vpush(out, ENC_RI(OP_ADDI, 6, 31, 0)); // v6 = 0
    
    int multiply_loop = out->n;
    
    // 检查加法计数器 < j
    vpush(out, ENC_RRR(OP_CMPrr, 0, 6, 4)); // CMP v6, v4 (计数器, j)
    int multiply_bcc_pos = out->n;
    vpush(out, ENC_BR(OP_BCC, 0) | (3u<<19)); // BCC LT (如果计数器<j则继续)
    
    // 执行加法: 结果 += i
    vpush(out, ENC_RRR(OP_ADD, 5, 5, 2)); // v5 += v2 (结果 += i)
    vpush(out, ENC_RI(OP_ADDI, 6, 6, 1)); // v6++ (计数器++)
    vpush(out, ENC_BR(OP_B, multiply_loop - out->n)); // 跳回乘法循环
    
    // 乘法结束，v5中存储了 i*j 的结果
    
    // 调用宿主函数打印结果
    // 准备参数: v0=i, v1=j, v2=result
    vpush(out, ENC_RRR(OP_MOVrr, 0, 2, 31)); // v0 = i
    vpush(out, ENC_RRR(OP_MOVrr, 1, 4, 31)); // v1 = j
    vpush(out, ENC_RRR(OP_MOVrr, 2, 5, 31)); // v2 = result
    vpush(out, ENC_BR(OP_BL, 0)); // 调用宿主函数，索引0
    
    // 内层循环继续
    int multiply_exit = out->n;
    
    // 回填乘法循环的分支偏移
    int multiply_bcc_offset = multiply_exit - multiply_bcc_pos;
    out->v[multiply_bcc_pos] = (out->v[multiply_bcc_pos] & 0xFFE00000) | (multiply_bcc_offset & 0x1FFFFF);
    
    // j++
    vpush(out, ENC_RI(OP_ADDI, 4, 4, 1)); // v4++ (j++)
    vpush(out, ENC_BR(OP_B, inner_loop - out->n)); // 跳回内层循环
    
    // 内层循环结束，打印换行
    // 调用宿主函数打印换行
    vpush(out, ENC_RI(OP_ADDI, 0, 31, 0)); // v0 = 0 (特殊标记)
    vpush(out, ENC_RI(OP_ADDI, 1, 31, 0)); // v1 = 0
    vpush(out, ENC_RI(OP_ADDI, 2, 31, -1)); // v2 = -1 (换行标记)
    vpush(out, ENC_BR(OP_BL, 1)); // 调用宿主函数，索引1
    
    // 外层循环继续
    int inner_exit = out->n;
    
    // 回填内层循环的分支偏移
    int inner_bcc_offset = inner_exit - inner_bcc_pos;
    out->v[inner_bcc_pos] = (out->v[inner_bcc_pos] & 0xFFE00000) | (inner_bcc_offset & 0x1FFFFF);
    
    // i++
    vpush(out, ENC_RI(OP_ADDI, 2, 2, 1)); // v2++ (i++)
    vpush(out, ENC_BR(OP_B, outer_loop - out->n)); // 跳回外层循环
    
    // 程序结束
    int outer_exit = out->n;
    
    // 回填外层循环的分支偏移
    int outer_bcc_offset = outer_exit - outer_bcc_pos;
    out->v[outer_bcc_pos] = (out->v[outer_bcc_pos] & 0xFFE00000) | (outer_bcc_offset & 0x1FFFFF);
    
    // 返回
    vpush(out, ENC_RRR(OP_MOVrr, 0, 31, 31)); // v0 = 0
    vpush(out, ENC_RRR(OP_RET, 0,0,0)); // RET
}

// 宿主函数：打印换行
long long print_newline(const uint64_t* regs) {
    if ((long long)regs[2] == -1) {
        printf("\n");
    }
    return 0;
}

int main(){
    // 设置Windows控制台代码页为UTF-8，解决中文乱码问题
    #ifdef _WIN32
    system("chcp 65001 > nul");
    #endif
    
    printf("=== VMP 99乘法表演示 ===\n");
    
    // 构造字节码
    Vec bc;
    build_full_multiplication_table(&bc);
    
    // 组装 blob
    vmp_bc_header_t hdr;
    memcpy(hdr.magic,"LVMP",4);
    hdr.version=1;
    hdr.flags=0; // 关闭trace
    hdr.reserved=0;
    hdr.code_words=bc.n;
    
    printf("字节码长度: %d 条指令\n", bc.n);
    printf("正在生成99乘法表...\n\n");
    
    int blob_len = (int)sizeof(hdr) + bc.n*4;
    uint8_t* blob = (uint8_t*)malloc(blob_len);
    memcpy(blob, &hdr, sizeof(hdr));
    memcpy(blob+sizeof(hdr), bc.v, bc.n*4);
    
    // 加密
    uint64_t key=0xBADC0FFEE0DDF00Dull;
    uint64_t tweak=(uint64_t)time(NULL);
    lvmp_encrypt(blob+sizeof(hdr), bc.n*4, key, tweak);
    
    // 准备宿主函数
    vmp_thunk_t thunks[2];
    thunks[0] = print_multiplication_item;  // 打印乘法项
    thunks[1] = print_newline;  // 打印换行
    
    // 调用VM
    long long result = lvmp_entry(blob, blob_len, NULL, 0, thunks, 2, key, tweak);
    
    printf("\n\n99乘法表生成完成，返回值: %lld\n", result);
    
    free(bc.v);
    free(blob);
    return 0;
}