#pragma once // 防止重复包含
#include <stdint.h> // 固定宽度整数


/*
* 教学用“流式异或”接口：
* - 接口稳定，可随时换成 AES-CTR/ChaCha20 实现。
* - 参数：buf/len 指向要加解密的缓冲；key/tweak 用于派生子密钥流。
*/
void lvmp_encrypt(uint8_t* buf, int len, uint64_t key, uint64_t tweak);