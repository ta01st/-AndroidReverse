#pragma once // 防止重复包含
#include <stdint.h> // 固定宽度整数
#include <string.h> // memcpy 等（有时用于清零）
#include "vmp/opcode.h" // 依赖 ISA 定义


/*
* VMState：虚拟机的“CPU 状态”。
* - 32 个 64 位通用寄存器（v0..v31），v31 约定为零寄存器（读恒 0 / 写忽略）。
* - NZCV 旗标：Negative/Zero/Carry/Overflow（与 ARM 语义一致）。
*/
typedef struct {
uint64_t R[32]; // 通用寄存器堆
uint8_t N,Z,C,V;// 四个一位旗标
} VMState;


// —— 读/写寄存器（封装 v31=0 的约定） ——
static inline uint64_t VR(const VMState* s, uint8_t i){ return i==31?0ull:s->R[i]; }
static inline void VW( VMState* s, uint8_t i, uint64_t v){ if(i!=31) s->R[i]=v; }


// —— 根据结果 r 更新 N/Z（算术或逻辑完成后常用） ——
static inline void setNZ( VMState* s, uint64_t r){ s->Z=(r==0); s->N=(uint8_t)((r>>63)&1); }


/*
* 关键：按照 ARM 语义计算 C/V（进位/溢出）。
* - 加法：
* C = (r < a) // 无符号进位
* V = (~(a^b) & (a^r)) >> 63 // 有符号溢出：a、b 同号，但 r 与 a 异号
* - 减法：
* C = (a >= b) // ARM 约定：C=1 表示“无借位”
* V = ((a^b) & (a^r)) >> 63 // 有符号溢出：a、b 异号，且 r 与 a 异号
*/
static inline void setNZ_add(VMState* s, uint64_t a, uint64_t b, uint64_t r){
setNZ(s, r); // 先更新 N/Z
s->C = (r < a); // 无符号进位
s->V = (uint8_t)((~(a ^ b) & (a ^ r)) >> 63); // 有符号溢出
}
static inline void setNZ_sub(VMState* s, uint64_t a, uint64_t b, uint64_t r){
setNZ(s, r); // 更新 N/Z
s->C = (a >= b); // 无借位时 C=1
s->V = (uint8_t)(((a ^ b) & (a ^ r)) >> 63); // 有符号溢出
}


/*
* 教学用 trace 宏：编译期可通过 -DLVMP_TRACE=1 开启；
* 解释器运行时还会读取 bytecode header 的 flags 控制是否打印。
*/
#ifndef LVMP_TRACE
#define LVMP_TRACE 0
#endif
#if LVMP_TRACE
#include <stdio.h>
#define TRACE(fmt, ...) do{ fprintf(stderr,"[LVMP] " fmt "\n", ##__VA_ARGS__); }while(0)
#else
#define TRACE(...) do{}while(0)
#endif