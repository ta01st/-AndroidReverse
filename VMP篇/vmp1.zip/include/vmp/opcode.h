#pragma once // 防止头文件被重复包含
#include <stdint.h> // 使用固定宽度整数类型


/*
* LearnVMP ISA（教学版）：
* - 每条指令定长 32 bit，便于回填/对齐/分段解密。
* - 布局：
* [31..24]=opcode | [23..19]=rd | [18..14]=ra | [13..9]=rb | [8..0]=imm9 (signed)
* - 分支类（B/BCC）使用 21 位有符号相对位移（单位=指令数）。
*/


typedef uint32_t vm_insn_t; // 字节码中一条“指令”就是一个 32 位 word


// —— 操作码枚举：按功能分组，数值稳定利于教学/调试 ——
enum vm_op {
OP_NOP=0, // 空操作，占位/对齐
OP_LIMM, // 加载 64 位立即数（指令后紧跟 2 个 32 位字）
OP_MOVrr, // 寄存器拷贝


OP_ADD, OP_ADDI,// 加法（RRR/RI）
OP_SUB, OP_SUBI,// 减法（RRR/RI）
OP_AND, OP_ORR, OP_EOR, // 按位与/或/异或
OP_LSL, OP_LSR, OP_ASR, // 左移/逻辑右移/算术右移


OP_CMPrr, OP_CMPri, // 比较，更新 NZCV 旗标，不写回结果


// 访存：基址 + 有符号偏移（imm9），载入时零扩展到 64 位
OP_LDRB, OP_LDRH, OP_LDRW, OP_LDRX,
OP_STRB, OP_STRH, OP_STRW, OP_STRX,


// 控制流与桥接
OP_B, OP_BCC, // 无条件/条件分支（相对 PC，单位=指令数）
OP_BL, // 调用宿主 thunk：v0..v7 传参，v0 收返回值
OP_RET, // 从 VM 返回（返回值在 v0）


OP_TRAP, // 陷阱（错误/未实现）
OP_MAX_ // 表尾（非指令）
};


// —— 取字段工具（与编码布局一致） ——
static inline uint8_t op (vm_insn_t x){ return (x>>24)&0xFF; } // 取 opcode
static inline uint8_t rd (vm_insn_t x){ return (x>>19)&0x1F; } // 取 rd 索引
static inline uint8_t ra (vm_insn_t x){ return (x>>14)&0x1F; } // 取 ra 索引
static inline uint8_t rb (vm_insn_t x){ return (x>>9) &0x1F; } // 取 rb 索引
static inline int32_t imm9(vm_insn_t x){ // 取 9 位有符号立即数
int32_t v=(int32_t)(x & 0x1FF); // 低 9 位
return (v<<23)>>23; // 算术扩展到 32 位
}
static inline int32_t br_off_se21(vm_insn_t x){ // 取 21 位有符号分支位移
int32_t v=(int32_t)(x & 0x1FFFFF); // 低 21 位
return (v<<11)>>11; // 算术扩展到 32 位
}


// —— 编码器（把字段写回 32 位指令） ——
static inline vm_insn_t ENC_RRR(uint8_t o,uint8_t d,uint8_t a,uint8_t b){
return ((vm_insn_t)o<<24)|((vm_insn_t)d<<19)|((vm_insn_t)a<<14)|((vm_insn_t)b<<9);
}
static inline vm_insn_t ENC_RI (uint8_t o,uint8_t d,uint8_t a,int32_t i){
return ((vm_insn_t)o<<24)|((vm_insn_t)d<<19)|((vm_insn_t)a<<14)|((i)&0x1FF);
}
static inline vm_insn_t ENC_MEM(uint8_t o,uint8_t d,uint8_t a,int32_t off){
return ((vm_insn_t)o<<24)|((vm_insn_t)d<<19)|((vm_insn_t)a<<14)|((off)&0x1FF);
}
static inline vm_insn_t ENC_BR (uint8_t o,int32_t off){
return ((vm_insn_t)o<<24)|((off)&0x1FFFFF); // 分支位移也塞在低 21 位
}


/*
* LearnVMP 字节码“容器”头（教学指纹十分明显）：
* magic="LVMP" + version + flags + 指令数。
* 解释器会校验 magic/version，并按 flags 控制 trace 等行为。
*/
typedef struct __attribute__((packed)) {
char magic[4]; // 固定魔数 'L','V','M','P'
uint8_t version; // 版本号，教学版定为 1
uint8_t flags; // bit0: TRACE 开关
uint16_t reserved; // 预留
uint32_t code_words; // 后续指令区的“条数”（单位：word=4B）
} vmp_bc_header_t;


enum { LVMP_TRACE_FLAG = 1u<<0 };