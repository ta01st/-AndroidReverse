#include <stdint.h> // uint64_t, uint8_t等类型
#include "vmp/encrypt.h" // 声明接口


// 简易 xorshift64 伪随机生成器（教学演示；生产请更换为可靠流加密）
static inline uint64_t xorshift64(uint64_t* s){
uint64_t x=*s; // 取当前状态
x ^= x << 13; // 线性反馈变换 1
x ^= x >> 7; // 线性反馈变换 2
x ^= x << 17; // 线性反馈变换 3
return *s = x; // 更新状态并返回
}


// 对称“加/解密”：同一函数，重复调用即可还原
void lvmp_encrypt(uint8_t* buf, int len, uint64_t key, uint64_t tweak){
// 用 key 与 tweak 混合成初始状态；黄金比例常数增加扩散性
uint64_t st = key ^ (tweak*0x9E3779B97F4A7C15ull);
for (int i=0;i<len;i++){
if ((i & 7) == 0) (void)xorshift64(&st); // 每 8 字节推进一次状态
// 取状态的对应字节作为“密钥流”字节，与明文字节异或
buf[i] ^= (uint8_t)(st >> ((i & 7) * 8));
}
}