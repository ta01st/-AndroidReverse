#include <stdlib.h> // malloc/free
#include <string.h> // memcpy
#include <stdbool.h> // bool
#include <stdint.h> // uint64_t, uint8_t等类型
#include <time.h> // time
#include "vmp/state.h" // VMState 等定义
#include "vmp/encrypt.h" // lvmp_encrypt

// 动态数组（教学用简单版本）
typedef struct {
    uint32_t* v; // 数据缓冲
    int n, cap; // 当前大小和容量
} Vec;

// 初始化动态数组
static void vinit(Vec* vec) {
    vec->v = NULL;
    vec->n = 0;
    vec->cap = 0;
}

// 向动态数组追加元素
static void vpush(Vec* vec, uint32_t val) {
    if (vec->n >= vec->cap) {
        vec->cap = vec->cap ? vec->cap * 2 : 16;
        vec->v = (uint32_t*)realloc(vec->v, vec->cap * sizeof(uint32_t));
    }
    vec->v[vec->n++] = val;
}

// 宿主函数指针类型
typedef long long (*vmp_thunk_t)(const uint64_t* regs);

// VM入口函数实现
long long lvmp_entry(const uint8_t* blob, int blob_len,
                     const uint64_t* args, int nargs,
                     vmp_thunk_t* thunks, int nthunks,
                     uint64_t func_key, uint64_t runtime_tweak) {
    
    // 校验头部
    if (blob_len < (int)sizeof(vmp_bc_header_t)) {
        TRACE("blob too small");
        return -1;
    }
    
    const vmp_bc_header_t* hdr = (const vmp_bc_header_t*)blob;
    if (memcmp(hdr->magic, "LVMP", 4) != 0) {
        TRACE("bad magic");
        return -1;
    }
    if (hdr->version != 1) {
        TRACE("bad version");
        return -1;
    }
    
    bool enable_trace = (hdr->flags & LVMP_TRACE_FLAG) != 0;
    
    // 计算代码区大小并复制
    int code_bytes = hdr->code_words * 4;
    if (blob_len < (int)sizeof(vmp_bc_header_t) + code_bytes) {
        TRACE("code section too small");
        return -1;
    }
    
    uint8_t* code_buf = (uint8_t*)malloc(code_bytes);
    if (!code_buf) {
        TRACE("malloc failed");
        return -1;
    }
    
    memcpy(code_buf, blob + sizeof(vmp_bc_header_t), code_bytes);
    
    // 解密代码区
    lvmp_encrypt(code_buf, code_bytes, func_key, runtime_tweak);
    
    const uint32_t* code = (const uint32_t*)code_buf;
    int n = hdr->code_words;
    
    // 初始化VM状态
    VMState S;
    memset(&S, 0, sizeof(S));
    
    // 设置参数
    for (int i = 0; i < nargs && i < 32; i++) {
        VW(&S, i, args[i]);
    }
    
    // 执行循环
    int pc = 0;
    while (pc < n) {
        vm_insn_t ins = code[pc];
        uint8_t opc = op(ins);
        
        if (enable_trace) {
            TRACE("PC=%d op=%u ins=0x%08x", pc, opc, ins);
        }
        
        switch (opc) {
        case OP_NOP: // 空操作
            pc++;
            break;
            
        case OP_LIMM: { // 加载64位立即数
            uint8_t dst = rd(ins);
            if (pc + 2 >= n) {
                TRACE("LIMM OOB");
                goto TRAP;
            }
            uint64_t val = ((uint64_t)code[pc+1]) | (((uint64_t)code[pc+2]) << 32);
            VW(&S, dst, val);
            pc += 3;
            break;
        }
        
        case OP_MOVrr: { // 寄存器拷贝
            uint8_t dst = rd(ins), src = ra(ins);
            VW(&S, dst, VR(&S, src));
            pc++;
            break;
        }
        
        case OP_ADD: { // 加法 RRR
            uint8_t dst = rd(ins), a_reg = ra(ins), b_reg = rb(ins);
            uint64_t a = VR(&S, a_reg), b = VR(&S, b_reg);
            uint64_t r = a + b;
            VW(&S, dst, r);
            pc++;
            break;
        }
        
        case OP_ADDI: { // 加法 RI
            uint8_t dst = rd(ins), a_reg = ra(ins);
            int32_t imm = imm9(ins);
            uint64_t a = VR(&S, a_reg);
            uint64_t r = a + (uint64_t)(int64_t)imm;
            VW(&S, dst, r);
            pc++;
            break;
        }
        
        case OP_SUB: { // 减法 RRR
            uint8_t dst = rd(ins), a_reg = ra(ins), b_reg = rb(ins);
            uint64_t a = VR(&S, a_reg), b = VR(&S, b_reg);
            uint64_t r = a - b;
            VW(&S, dst, r);
            pc++;
            break;
        }
        
        case OP_LSL: { // 左移
            uint8_t dst = rd(ins), a_reg = ra(ins), b_reg = rb(ins);
            uint64_t a = VR(&S, a_reg), b = VR(&S, b_reg);
            uint64_t r = (b >= 64) ? 0 : (a << b);
            VW(&S, dst, r);
            pc++;
            break;
        }
        
        case OP_CMPrr: { // 比较 RRR
            uint8_t a_reg = ra(ins), b_reg = rb(ins);
            uint64_t a = VR(&S, a_reg), b = VR(&S, b_reg);
            uint64_t r = a - b;
            setNZ_sub(&S, a, b, r);
            pc++;
            break;
        }
        
        case OP_LDRX: { // 加载64位
            uint8_t dst = rd(ins), base = ra(ins);
            int32_t off = imm9(ins);
            uint64_t addr = VR(&S, base) + (int64_t)off;
            uint64_t val = *(const uint64_t*)(uintptr_t)addr;
            VW(&S, dst, val);
            pc++;
            break;
        }
        
        case OP_B:{ // 无条件分支
            int32_t off = br_off_se21(ins); // 取 21 位有符号位移
            int nxt = pc + off; // 计算目标 PC
            if ((unsigned)nxt >= (unsigned)n){ // 越界保护
                TRACE("B OOB");
                goto TRAP; // 异常退出
            }
            pc = nxt; // 跳转
            break;
        }
        
        case OP_BCC:{ // 条件分支
            uint8_t cond = (rd(ins) & 0xF); // 条件码写在 rd 的低 4 位
            bool take=false; // 是否命中
            switch(cond){ // 按 ARM 语义判断
                case 0: take= S.Z; break; // EQ: 等于
                case 1: take=!S.Z; break; // NE: 不等
                case 2: take= S.N==S.V; break; // GE: 大于等于（有符号）
                case 3: take= S.N!=S.V; break; // LT: 小于（有符号）
                case 4: take=!S.C && !S.Z; break; // HI: 大于（无符号）
                case 5: take= S.C; break; // CS: 大于等于（无符号）
                case 6: take=!S.C; break; // CC: 小于（无符号）
                case 7: take= S.C || S.Z; break; // LS: 小于等于（无符号）
                default: take=false; break; // 其它值视为不跳
            }
            if (take){ // 命中则计算目标
                int32_t off = br_off_se21(ins);
                int nxt = pc + off;
                if ((unsigned)nxt >= (unsigned)n){ TRACE("BCC OOB"); goto TRAP; }
                pc = nxt; // 执行跳转
            } else {
                pc++; // 未命中则顺序执行
            }
            break;
        }
        
        case OP_BL:{ // 调用宿主 thunk
            uint32_t idx = code[pc] & 0xFFFFu; // 索引放在低 16 位
            if ((int)idx < nthunks && thunks[idx]){ // 索引有效且存在函数
                long long r = thunks[idx](S.R); // 以 R 作为参数块调用
                VW(&S,0,(uint64_t)r); // 返回值写 v0
            }
            pc++; break; // 前进一步
        }
        
        case OP_RET:{ // 从 VM 返回
            long long ret = (long long)VR(&S,0); // 从 v0 取返回值
            lvmp_encrypt(code_buf, code_bytes, func_key, runtime_tweak); // 退出前抹回密文
            free(code_buf); // 释放缓冲
            return ret; // 返回给宿主
        }
        
        default: // 未知 opcode → 陷阱
        case OP_TRAP:
            TRACE("TRAP op=%u", opc); // 打日志
            goto TRAP; // 统一异常出口
        }
    }
    
TRAP: // —— 异常出口 ——
    lvmp_encrypt(code_buf, code_bytes, func_key, runtime_tweak); // 抹回密文
    free(code_buf); // 释放缓冲
    return -1; // 返回错误码
}