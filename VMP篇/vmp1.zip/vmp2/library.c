// irvm.c — 纯C单文件：pass仅给符号名，VM自解并缓存（含 alloca/load/store/printf/putchar 测试）
// 构建(Linux/WSL):  gcc -O2 -Wall -Wextra -rdynamic -ldl -o irvm irvm.c
// 运行: ./irvm
// 若在 Android：把 host_add 放到 libvmhost.so 然后用 "libvmhost.so::host_add" 即可。

#include <stdint.h>
#include <inttypes.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#if !defined(VM_TRACE)
#define VM_TRACE 1
#endif
#if VM_TRACE
#  define TR(fmt, ...) fprintf(stderr, "[vm] " fmt "\n", ##__VA_ARGS__)
#else
#  define TR(fmt, ...) ((void)0)
#endif

#ifndef VM_CALL_ARG_MAX
#define VM_CALL_ARG_MAX 16
#endif
#define VM_MEM_SIZE   4096
#define VM_MAX_SYMS   256
#define U64(x) ((uint64_t)(x))
#define PTR2U64(p) ((uint64_t)(uintptr_t)(p))
#define U642PTR(x) ((void*)(uintptr_t)(x))
#define MIN(a,b) ((a)<(b)?(a):(b))

#if defined(__unix__) || defined(__APPLE__)
#  include <dlfcn.h>
#  ifndef VM_HAVE_DLOPEN
#    define VM_HAVE_DLOPEN 1
#  endif
#else
#  define VM_HAVE_DLOPEN 0
#endif

enum Op : uint8_t {
  OP_HLT=0x00, OP_LDARG=0x01, OP_LOADK=0x02, OP_MOV=0x03,
  OP_ADD=0x10, OP_SUB=0x11, OP_MUL=0x12, OP_UDIV=0x13,
  OP_PUSHARG=0x20, OP_CLEARARGS=0x21, OP_CALL_SYM=0x22, OP_RET=0x30,
  OP_ALLOCA4=0x40, OP_STORE32=0x41, OP_LOAD32=0x42, OP_SX32=0x43
};

typedef struct VM {
  uint64_t r[16];
  uint64_t call_args[VM_CALL_ARG_MAX];
  uint8_t  call_argc;
  uint8_t  mem[VM_MEM_SIZE];
  uint32_t sp;
  // 懒解析 GOT
  void*    sym_ptr[VM_MAX_SYMS];
  uint8_t  sym_resolved[VM_MAX_SYMS];
} VM;

static inline int fetch_u8(const uint8_t**ip,const uint8_t*end,uint8_t*out){ if(*ip>=end) return 0; *out=*(*ip)++; return 1; }
static inline int fetch_u8_2(const uint8_t**ip,const uint8_t*end,uint8_t*a,uint8_t*b){ return fetch_u8(ip,end,a)&&fetch_u8(ip,end,b); }
static inline int fetch_u8_3(const uint8_t**ip,const uint8_t*end,uint8_t*a,uint8_t*b,uint8_t*c){ return fetch_u8(ip,end,a)&&fetch_u8(ip,end,b)&&fetch_u8(ip,end,c); }

typedef uint64_t (*fn0_t)(void);
typedef uint64_t (*fn1_t)(uint64_t);
typedef uint64_t (*fn2_t)(uint64_t,uint64_t);
typedef uint64_t (*fn3_t)(uint64_t,uint64_t,uint64_t);
typedef uint64_t (*fn4_t)(uint64_t,uint64_t,uint64_t,uint64_t);
typedef uint64_t (*fn5_t)(uint64_t,uint64_t,uint64_t,uint64_t,uint64_t);
typedef uint64_t (*fn6_t)(uint64_t,uint64_t,uint64_t,uint64_t,uint64_t,uint64_t);
typedef uint64_t (*fn7_t)(uint64_t,uint64_t,uint64_t,uint64_t,uint64_t,uint64_t,uint64_t);
typedef uint64_t (*fn8_t)(uint64_t,uint64_t,uint64_t,uint64_t,uint64_t,uint64_t,uint64_t,uint64_t);

static inline int mem_bounds(uint32_t a,uint32_t s){ return a+s<=VM_MEM_SIZE; }
static inline void mem_store32(VM*vm,uint32_t a,uint32_t v){
  if(!mem_bounds(a,4)){ TR("STORE32 OOB @%u",a); return; }
  vm->mem[a+0]=(uint8_t)v; vm->mem[a+1]=(uint8_t)(v>>8);
  vm->mem[a+2]=(uint8_t)(v>>16); vm->mem[a+3]=(uint8_t)(v>>24);
}
static inline uint32_t mem_load32(VM*vm,uint32_t a){
  if(!mem_bounds(a,4)){ TR("LOAD32 OOB @%u",a); return 0; }
  uint32_t v=0;
  v|=(uint32_t)vm->mem[a+0];
  v|=(uint32_t)vm->mem[a+1]<<8;
  v|=(uint32_t)vm->mem[a+2]<<16;
  v|=(uint32_t)vm->mem[a+3]<<24;
  return v;
}

#if VM_HAVE_DLOPEN
static int is_ascii_cstr(const void* p){
  if(!p) return 0; const char*s=(const char*)p; int n=0;
  while(n<256 && s[n]){ unsigned char c=(unsigned char)s[n]; if(c<0x20||c>0x7E) return 0; n++; }
  return n>0 && n<256 && s[n]=='\0';
}
static void* resolve_with_hint(const char* lib,const char* sym){
  void* fp=NULL;
  if(lib && *lib){
    void* h = dlopen(lib, RTLD_LAZY|RTLD_LOCAL);
    if(!h){ TR("dlopen('%s') fail: %s",lib,dlerror()); return NULL; }
    fp = dlsym(h, sym);
    TR("dlsym(%s::%s) -> %p", lib, sym, fp);
  }else{
    fp = dlsym(RTLD_DEFAULT, sym);
    TR("dlsym(DEFAULT::%s) -> %p", sym, fp);
  }
  if(!fp){
    // 兜底尝试常见库名
    const char* fb[]={"libc.so","libc.so.6","libm.so","libdl.so"};
    for(size_t i=0;i<sizeof(fb)/sizeof(fb[0]) && !fp;i++){
      void*h=dlopen(fb[i],RTLD_LAZY|RTLD_LOCAL);
      if(h){ fp=dlsym(h,sym); TR("fallback %s::%s -> %p",fb[i],sym,fp); }
    }
  }
  return fp;
}
// 解析 "lib::sym" / "lib!sym" / "sym"
static void* resolve_by_spec(const char* spec){
  if(!spec) return NULL;
  const char* bang=strchr(spec,'!');
  const char* dcol=strstr(spec,"::");
  if(bang || dcol){
    size_t liblen=(size_t)((bang?bang:dcol)-spec);
    char lib[160]; if(liblen>=sizeof(lib)) liblen=sizeof(lib)-1;
    memcpy(lib,spec,liblen); lib[liblen]=0;
    const char* sym=(bang?bang+1:dcol+2);
    return resolve_with_hint(lib,sym);
  }
  return resolve_with_hint(NULL, spec);
}
#else
static int   is_ascii_cstr(const void* p){ (void)p; return 0; }
static void* resolve_by_spec(const char* s){ (void)s; return NULL; }
#endif

uint64_t vm_exec(const uint8_t* code,uint32_t code_size,
                 void** args,uint64_t num,void** gsyms,void** rel_agrs){
  (void)num;
  VM vm; memset(&vm,0,sizeof(vm));
  const uint8_t* ip=code; const uint8_t* end=code+code_size;
  TR("start vm_exec size=%u", code_size);

  while(ip<end){
    uint8_t op=0; if(!fetch_u8(&ip,end,&op)){ TR("OOB opcode"); break; }
    switch(op){
      case OP_HLT: TR("HLT"); goto DONE;

      case OP_LDARG: {
        uint8_t rd=0, aidx=0; if(!fetch_u8_2(&ip,end,&rd,&aidx)){ TR("bad LDARG"); goto DONE; }
        vm.r[rd]=args?PTR2U64(args[aidx]):0;
        TR("LDARG r%d = args[%u] -> 0x%llx", rd, aidx, (unsigned long long)vm.r[rd]);
      } break;

      case OP_LOADK: {
        uint8_t rd=0, k=0; if(!fetch_u8_2(&ip,end,&rd,&k)){ TR("bad LOADK"); goto DONE; }
        vm.r[rd]=rel_agrs?PTR2U64(rel_agrs[k]):0;
        TR("LOADK r%d = rel[%u] -> 0x%llx", rd, k, (unsigned long long)vm.r[rd]);
      } break;

      case OP_MOV: {
        uint8_t rd=0, rs=0; if(!fetch_u8_2(&ip,end,&rd,&rs)){ TR("bad MOV"); goto DONE; }
        vm.r[rd]=vm.r[rs]; TR("MOV r%d = r%d -> 0x%llx", rd, rs, (unsigned long long)vm.r[rd]);
      } break;

      case OP_ADD: case OP_SUB: case OP_MUL: case OP_UDIV: {
        uint8_t rd=0, ra=0, rb=0; if(!fetch_u8_3(&ip,end,&rd,&ra,&rb)){ TR("bad ALU"); goto DONE; }
        uint64_t a=vm.r[ra], b=vm.r[rb], r=0;
        if(op==OP_ADD) r=a+b; else if(op==OP_SUB) r=a-b; else if(op==OP_MUL) r=a*b; else r=(b? a/b:0);
        vm.r[rd]=r; TR("%s r%d = %llu %s %llu -> %llu",
          op==OP_ADD?"ADD":op==OP_SUB?"SUB":op==OP_MUL?"MUL":"UDIV",
          rd,(unsigned long long)a,(op==OP_ADD?"+":op==OP_SUB?"-":op==OP_MUL?"*":"/"),
          (unsigned long long)b,(unsigned long long)r);
      } break;

      case OP_PUSHARG: {
        uint8_t rs=0; if(!fetch_u8(&ip,end,&rs)){ TR("bad PUSHARG"); goto DONE; }
        if(vm.call_argc>=VM_CALL_ARG_MAX){ TR("PUSHARG overflow"); break; }
        vm.call_args[vm.call_argc++]=vm.r[rs];
        TR("PUSHARG r%d -> arg[%u]=0x%llx", rs, vm.call_argc-1, (unsigned long long)vm.r[rs]);
      } break;

      case OP_CLEARARGS: vm.call_argc=0; TR("CLEARARGS"); break;

      case OP_CALL_SYM: {
        uint8_t sym=0, argc=0; if(!fetch_u8_2(&ip,end,&sym,&argc)){ TR("bad CALL_SYM"); goto DONE; }
        void* fp=NULL;
        if(sym<VM_MAX_SYMS && vm.sym_resolved[sym]) fp=vm.sym_ptr[sym];
        else{
          void* meta=gsyms?gsyms[sym]:NULL;
          if(is_ascii_cstr(meta)) fp=resolve_by_spec((const char*)meta);
          if(sym<VM_MAX_SYMS){ vm.sym_ptr[sym]=fp; vm.sym_resolved[sym]=1; }
        }
        if(!fp){ TR("CALL_SYM[%u] unresolved", sym); vm.r[0]=0; break; }

        uint64_t a[VM_CALL_ARG_MAX]={0}; uint8_t realc=(uint8_t)MIN(argc, vm.call_argc);
        for(uint8_t i=0;i<realc;i++) a[i]=vm.call_args[i];

        uint64_t ret=0;
        switch(realc){
          case 0: ret=((fn0_t)fp)(); break;
          case 1: ret=((fn1_t)fp)(a[0]); break;
          case 2: ret=((fn2_t)fp)(a[0],a[1]); break;
          case 3: ret=((fn3_t)fp)(a[0],a[1],a[2]); break;
          case 4: ret=((fn4_t)fp)(a[0],a[1],a[2],a[3]); break;
          case 5: ret=((fn5_t)fp)(a[0],a[1],a[2],a[3],a[4]); break;
          case 6: ret=((fn6_t)fp)(a[0],a[1],a[2],a[3],a[4],a[5]); break;
          case 7: ret=((fn7_t)fp)(a[0],a[1],a[2],a[3],a[4],a[5],a[6]); break;
          default: ret=((fn8_t)fp)(a[0],a[1],a[2],a[3],a[4],a[5],a[6],a[7]); break;
        }
        vm.r[0]=ret; TR("CALL_SYM[%u] argc=%u -> r0=%llu", sym, realc, (unsigned long long)ret);
      } break;

      case OP_RET: {
        uint8_t rs=0; if(!fetch_u8(&ip,end,&rs)){ TR("bad RET"); goto DONE; }
        vm.r[0]=vm.r[rs]; TR("RET r%d -> %llu", rs, (unsigned long long)vm.r[0]); goto DONE;
      }

      case OP_ALLOCA4: {
        uint8_t rd=0, cnt=0; if(!fetch_u8_2(&ip,end,&rd,&cnt)){ TR("bad ALLOCA4"); goto DONE; }
        uint32_t bytes=(uint32_t)cnt*4u; vm.sp=(vm.sp+3u)&~3u;
        if(vm.sp+bytes>VM_MEM_SIZE){ TR("ALLOCA OOM"); vm.r[rd]=0; break; }
        uint32_t addr=vm.sp; vm.sp+=bytes; vm.r[rd]=U64(addr);
        TR("ALLOCA4 r%d = %u bytes @%u", rd, bytes, addr);
      } break;

      case OP_STORE32: {
        uint8_t raddr=0, rsrc=0; if(!fetch_u8_2(&ip,end,&raddr,&rsrc)){ TR("bad STORE32"); goto DONE; }
        mem_store32(&vm,(uint32_t)vm.r[raddr],(uint32_t)vm.r[rsrc]);
        TR("STORE32 [@%u] = 0x%08x (r%d)", (unsigned)vm.r[raddr], (unsigned)(uint32_t)vm.r[rsrc], rsrc);
      } break;

      case OP_LOAD32: {
        uint8_t rd=0, raddr=0; if(!fetch_u8_2(&ip,end,&rd,&raddr)){ TR("bad LOAD32"); goto DONE; }
        uint32_t v=mem_load32(&vm,(uint32_t)vm.r[raddr]); vm.r[rd]=(uint64_t)v;
        TR("LOAD32 r%d = [@%u] -> 0x%08x", rd, (unsigned)vm.r[raddr], v);
      } break;

      case OP_SX32: {
        uint8_t rd=0, rs=0; if(!fetch_u8_2(&ip,end,&rd,&rs)){ TR("bad SX32"); goto DONE; }
        int64_t v=(int64_t)(int32_t)(vm.r[rs]&0xFFFFFFFFu); vm.r[rd]=(uint64_t)v;
        TR("SX32 r%d = (int64)r%d(32) -> %lld", rd, rs, (long long)v);
      } break;

      default: TR("unknown opcode 0x%02x", op); goto DONE;
    }
  }
DONE:
  TR("finish r0=%llu", (unsigned long long)vm.r[0]);
  return vm.r[0];
}

/************** 测试：@add 与 @main **************/
static uint8_t* emit1(uint8_t* p,uint8_t op){ *p++=op; return p; }
static uint8_t* emit2(uint8_t* p,uint8_t op,uint8_t a){ *p++=op; *p++=a; return p; }
static uint8_t* emit3(uint8_t* p,uint8_t op,uint8_t a,uint8_t b){ *p++=op; *p++=a; *p++=b; return p; }
static uint8_t* emit4(uint8_t* p,uint8_t op,uint8_t a,uint8_t b,uint8_t c){ *p++=op; *p++=a; *p++=b; *p++=c; return p; }

static uint8_t g_code_add[128];  static uint32_t g_code_add_sz;
static uint8_t g_code_main[128]; static uint32_t g_code_main_sz;

// gsyms：全部是“符号名”
static void* g_syms_common[2] = { (void*)"printf", (void*)"putchar" };
static void* g_rels_add[2]    = { 0 }; // 0: "%d %d %d", 1: 10

static void* g_syms_main[3]   = { (void*)"printf", (void*)"putchar", (void*)"host_add" };
static void* g_rels_main[4]   = { 0 }; // 0:"ret=%d\n", 1:1, 2:2, 3:0

// 注意：host_add 也只用“名字”解析；可执行文件需 -rdynamic 才能被 dlsym 找到
static uint64_t host_add(uint64_t a, uint64_t b){
  void* args[2]={ U642PTR(a), U642PTR(b) };
  extern uint64_t vm_exec(const uint8_t*,uint32_t,void**,uint64_t,void**,void**);
  return vm_exec(g_code_add,g_code_add_sz,args,2,g_syms_common,g_rels_add);
}

static void build_code_add(void){
  uint8_t* w=g_code_add;
  // a.addr / b.addr
  w=emit3(w,OP_ALLOCA4,10,1);
  w=emit3(w,OP_ALLOCA4,11,1);
  // r0=a, r1=b
  w=emit3(w,OP_LDARG,0,0);
  w=emit3(w,OP_LDARG,1,1);
  // store
  w=emit3(w,OP_STORE32,10,0);
  w=emit3(w,OP_STORE32,11,1);
  // %0,%1
  w=emit3(w,OP_LOAD32,2,10);
  w=emit3(w,OP_LOAD32,3,11);
  // %2,%3
  w=emit3(w,OP_LOAD32,4,10);
  w=emit3(w,OP_LOAD32,5,11);
  // %add = r4+r5
  w=emit4(w,OP_ADD,6,4,5);
  // printf("%d %d %d", r2,r3,r6)
  w=emit3(w,OP_LOADK,7,0);
  w=emit1(w,OP_CLEARARGS);
  w=emit2(w,OP_PUSHARG,7);
  w=emit2(w,OP_PUSHARG,2);
  w=emit2(w,OP_PUSHARG,3);
  w=emit2(w,OP_PUSHARG,6);
  w=emit3(w,OP_CALL_SYM,0,4); // printf
  // putchar(10)
  w=emit3(w,OP_LOADK,8,1);
  w=emit1(w,OP_CLEARARGS);
  w=emit2(w,OP_PUSHARG,8);
  w=emit3(w,OP_CALL_SYM,1,1); // putchar
  // 再算并返回
  w=emit3(w,OP_LOAD32,9,10);
  w=emit3(w,OP_LOAD32,12,11);
  w=emit4(w,OP_ADD,13,9,12);
  w=emit2(w,OP_RET,13);
  g_code_add_sz=(uint32_t)(w-g_code_add);
}

static void build_code_main(void){
  uint8_t* w=g_code_main;
  // call host_add(1,2)
  w=emit3(w,OP_LOADK,0,1); // 1
  w=emit3(w,OP_LOADK,1,2); // 2
  w=emit1(w,OP_CLEARARGS);
  w=emit2(w,OP_PUSHARG,0);
  w=emit2(w,OP_PUSHARG,1);
  w=emit3(w,OP_CALL_SYM,2,2); // sym=2 -> "host_add"
  // printf("ret=%d\n", r0)
  w=emit3(w,OP_LOADK,2,0); // fmt
  w=emit1(w,OP_CLEARARGS);
  w=emit2(w,OP_PUSHARG,2);
  w=emit2(w,OP_PUSHARG,0);
  w=emit3(w,OP_CALL_SYM,0,2); // printf
  // ret 0
  w=emit3(w,OP_LOADK,3,3); // 0
  w=emit2(w,OP_RET,3);
  g_code_main_sz=(uint32_t)(w-g_code_main);
}

int main(void){
  char* ADD_FMT="a=%d, b=%d, sum=%d";
  char* MAIN_FMT="ret=%d\n";
  g_rels_add[0]=(void*)ADD_FMT; g_rels_add[1]=(void*)(uintptr_t)10;
  g_rels_main[0]=(void*)MAIN_FMT;
  g_rels_main[1]=(void*)(uintptr_t)1; g_rels_main[2]=(void*)(uintptr_t)2; g_rels_main[3]=(void*)(uintptr_t)0;

  build_code_add();
  build_code_main();

  // 直接跑 add(1,2)
  void* add_args[2]={ U642PTR(1), U642PTR(2) };
  uint64_t add_ret=vm_exec(g_code_add,g_code_add_sz,add_args,2,g_syms_common,g_rels_add);
  printf("[test] add(1,2) return = %llu\n",(unsigned long long)add_ret);

  // 跑 main()（内部通过名字解析 host_add）
  uint64_t main_ret=vm_exec(g_code_main,g_code_main_sz,NULL,0,g_syms_main,g_rels_main);
  printf("[test] main() return = %llu\n",(unsigned long long)main_ret);
  return 0;
}


/*
 * 针对 llvm ir 的 vmp 实现
 * 在pass 端 ：
 * 1. 先扫描function 里面 自动收集其必需的常量区/跳转表 到时候在有vm进行初始化 进行重定位
 * 2. 设定寄存器/栈布局与返回地址
 * 3. 尽可能的翻译 ir
 *
 *
 *
 *
 * Vmp端：
 * 1.用纯c实现，集成在一个文件里面
 * 2.根据pass 端 约定 设定寄存器/栈布局与返回地址
 * 3.自动初始化，把常量区/跳转表 重定位
 * 4.有trace 开关 方便测试
 * 5.需要一个 测试函数 类似下面的 内容
 *
 *
 * 实现外界无感知的调用，pass 会把ir 抽取转化为自己的 code ，清空ir 跳转到 vm
 *
 *
 *
*; Function Attrs: noinline nounwind uwtable
define dso_local i32 @add(i32 noundef %a, i32 noundef %b) #0 section ".irvm" {
entry:
  %a.addr = alloca i32, align 4
  %b.addr = alloca i32, align 4
  store i32 %a, ptr %a.addr, align 4
  store i32 %b, ptr %b.addr, align 4
  %0 = load i32, ptr %a.addr, align 4
  %1 = load i32, ptr %b.addr, align 4
  %2 = load i32, ptr %a.addr, align 4
  %3 = load i32, ptr %b.addr, align 4
  %add = add nsw i32 %2, %3
  %call = call i32 (ptr, ...) @printf(ptr noundef @.str.40, i32 noundef %0, i32 noundef %1, i32 noundef %add)
  %call1 = call i32 @putchar(i32 noundef 10)
  %4 = load i32, ptr %a.addr, align 4
  %5 = load i32, ptr %b.addr, align 4
  %add2 = add nsw i32 %4, %5
  ret i32 %add2
}
declare i32 @printf(ptr noundef, ...) #1
declare i32 @putchar(i32 noundef) #1
; Function Attrs: noinline nounwind uwtable
define dso_local i32 @main() #0 {
entry:
  %retval = alloca i32, align 4
  store i32 0, ptr %retval, align 4
  %call = call i32 @add(i32 noundef 1, i32 noundef 2)
  %call1 = call i32 (ptr, ...) @printf(ptr noundef @.str.43, i32 noundef %call)
  ret i32 0
}
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 */


