#ifndef VMP2_LIBRARY_H
#define VMP2_LIBRARY_H

void hello(void);

#endif // VMP2_LIBRARY_H