#include "../include/vm_imports.h"
#include <stdio.h>

long long vm_import_call_default(struct VMProc* P, int import_id, uint64_t* args, int argc){
    if (!P->imps.fns || import_id < 0 || import_id >= P->imps.n || !P->imps.fns[import_id]){
        P->trap = 1;
        fprintf(stderr, "[IRVM] TRAP: unresolved import id=%d\n", import_id);
        return 0;
    }
    return P->imps.fns[import_id](P, args, argc);
}
