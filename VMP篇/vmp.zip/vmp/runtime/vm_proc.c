#include "../include/vm_proc.h"
#include "../include/vm_imports.h"
#include <string.h>
#include <stdlib.h>

void vm_init(struct VMProc* P, uint8_t* mem, size_t memsz, VMFunc* funs, int nf){
    memset(P,0,sizeof(*P));
    P->mem=mem; P->mem_size=memsz; P->sp_global=0;
    P->mod.funcs=funs; P->mod.nfuncs=nf;
    P->imps.fns=NULL; P->imps.ctx=NULL; P->imps.names=NULL; P->imps.n=0;
    P->imps.call=vm_import_call_default;
    P->trace_hook=NULL; P->trace_user=NULL; P->trace_enabled=0;
    P->trap=0;
}

void vm_set_imports(struct VMProc* P, HostThunk3* fns, const char** names, int n){
    P->imps.fns=fns; P->imps.names=names; P->imps.n=n;
    if (!P->imps.call) P->imps.call=vm_import_call_default;
}
