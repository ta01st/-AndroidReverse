// runtime/vm_import_resolve.c
#include "../include/vm_import_resolve.h"

#ifndef _GNU_SOURCE
#define _GNU_SOURCE 1
#endif

#include <dlfcn.h>
#include <string.h>
#include <stdlib.h>
#include <stdio.h>
#include <stdint.h>

/* ============ 可选：开启已加载 so 遍历（默认关闭以保证编过） ============ */
/* 若要开启：在编译命令或 CMake 中定义 IRVM_ENABLE_PHDR_SCAN=1
 * 仅当系统确实有 <link.h> 且提供 dl_iterate_phdr 时才会启用。
 */
#if defined(IRVM_ENABLE_PHDR_SCAN) && IRVM_ENABLE_PHDR_SCAN
# if defined(__has_include)
#  if __has_include(<link.h>)
#   include <link.h>
#   define IRVM_HAVE_DL_ITERATE 1
#  endif
# endif
# ifndef RTLD_NOLOAD
#  define RTLD_NOLOAD 0
# endif
# if defined(IRVM_HAVE_DL_ITERATE)
typedef struct { const char* name; void* sym; } IRVM_FindCtx;
static int irvm_phdr_cb(struct dl_phdr_info* info, size_t size, void* data) {
    (void)size;
    IRVM_FindCtx* c = (IRVM_FindCtx*)data;
    if (!info || !info->dlpi_name || !info->dlpi_name[0]) return 0;
    void* h = dlopen(info->dlpi_name, RTLD_LAZY | RTLD_LOCAL | RTLD_NOLOAD);
    if (!h) return 0;
    void* s = dlsym(h, c->name);
    if (s) { c->sym = s; return 1; }
    return 0;
}
# endif
#endif /* IRVM_ENABLE_PHDR_SCAN */

/* ===================== 无 libffi（整数/指针） ===================== */
typedef enum { AK_I32, AK_I64, AK_PTR_VM, AK_PTR_HOST } ArgKind;
typedef enum { RK_VOID, RK_I32, RK_I64, RK_PTR } RetKind;

typedef struct {
  void*    fn_ptr;
  RetKind  retk;
  ArgKind  kinds[6];
  int      argc;
} ImportCtx;

long long vm_import_call_ffi(struct VMProc* P, int import_id, uint64_t* args, int argc);

/* 解析签名：支持 void/i32/i64/ptr（ptr[in vm]/ptr[host]） */
static int parse_sig_noffi(const char* sig, ImportCtx* C){
  char buf[256]; strncpy(buf, sig, sizeof(buf)-1); buf[sizeof(buf)-1]=0;
  char *lp=strchr(buf,'('), *rp=strrchr(buf,')'); if(!lp||!rp||rp<=lp) return -1;
  *lp=0; *rp=0;

  if(!strcmp(buf,"void")) C->retk=RK_VOID;
  else if(!strcmp(buf,"i32")) C->retk=RK_I32;
  else if(!strcmp(buf,"i64")) C->retk=RK_I64;
  else if(!strcmp(buf,"ptr")) C->retk=RK_PTR;
  else return -1;

  C->argc=0;
  for(char* p=lp+1; *p; ){
    while(*p==' '||*p==',') ++p; if(!*p) break;
    char* q=p; while(*q && *q!=',') ++q; char save=*q; *q=0;

    if(!strncmp(p,"i32",3)) C->kinds[C->argc]=AK_I32;
    else if(!strncmp(p,"i64",3)) C->kinds[C->argc]=AK_I64;
    else if(!strncmp(p,"ptr",3)) C->kinds[C->argc]= strstr(p,"host")? AK_PTR_HOST : AK_PTR_VM;
    else { *q=save; return -1; }

    C->argc++; if (C->argc>6){ *q=save; return -1; }
    *q=save; p=q;
  }
  return 0;
}

/* 按 64-bit GPR 直接调用（x86_64/AArch64 常见场景可用） */
#define IRVM_CALL6(RT,FN,A) ((RT(*)(uint64_t,uint64_t,uint64_t,uint64_t,uint64_t,uint64_t))(FN))(A[0],A[1],A[2],A[3],A[4],A[5])

static long long invoke_noffi(struct VMProc* P, uint64_t* vmargs, int vmargc, ImportCtx* C){
  if (!C || vmargc < C->argc){ P->trap=1; return 0; }
  uint64_t a[6]={0};
  for(int i=0;i<C->argc;i++){
    switch(C->kinds[i]){
      case AK_I32:     a[i]=(uint64_t)(uint32_t)vmargs[i]; break;
      case AK_I64:     a[i]=vmargs[i]; break;
      case AK_PTR_VM:  a[i]=(uint64_t)(uintptr_t)(P->mem + (size_t)vmargs[i]); break; // VM 偏移 → Host 指针
      case AK_PTR_HOST:a[i]=(uint64_t)vmargs[i]; break;
    }
  }
  switch(C->retk){
    case RK_VOID: IRVM_CALL6(void,   C->fn_ptr,a); return 0;
    case RK_I32:  return (long long)IRVM_CALL6(int32_t,C->fn_ptr,a);
    case RK_I64:  return (long long)IRVM_CALL6(int64_t,C->fn_ptr,a);
    case RK_PTR:  return (long long)(intptr_t)IRVM_CALL6(void*,C->fn_ptr,a);
  }
  return 0;
}

long long vm_import_call_ffi(struct VMProc* P, int import_id, uint64_t* args, int argc){
  if (P->imps.fns && import_id>=0 && import_id<P->imps.n && P->imps.fns[import_id]){
    return P->imps.fns[import_id](P, args, argc);
  }
  if (!P->imps.ctx || import_id<0 || import_id>=P->imps.n || !P->imps.ctx[import_id]){
    P->trap=1; fprintf(stderr,"[IRVM] TRAP: import id=%d unlinked\n", import_id); return 0;
  }
  ImportCtx* C=(ImportCtx*)P->imps.ctx[import_id];
  return invoke_noffi(P, args, argc, C);
}

static int bind_one_ctx(struct VMProc* P, void* sym, const char* sig, int slot){
  ImportCtx* C=(ImportCtx*)calloc(1,sizeof(ImportCtx));
  C->fn_ptr = sym;
  if (parse_sig_noffi(sig, C)!=0){ fprintf(stderr,"bad sig(no ffi): %s\n", sig); free(C); return -1; }
  P->imps.ctx[slot]=C;
  return 0;
}

/* —— 自动解析符号：RTLD_DEFAULT → 常见系统库（默认不遍历 so） —— */
static void* try_resolve_symbol_auto(const char* name){
  // 1) 全局符号表
  void* sym = dlsym(RTLD_DEFAULT, name);
  if (sym) return sym;

  // 2) 常见系统库（Android / glibc）
#if defined(__ANDROID__)
  static const char* libs[] = {"libc.so","libm.so","libdl.so","liblog.so","libandroid.so", NULL};
#else
  static const char* libs[] = {
    "libc.so.6","libm.so.6","libdl.so.2","librt.so.1","libpthread.so.0",
    "libc.so","libm.so","libdl.so", NULL
  };
#endif
  for (int i=0; libs[i]; ++i){
    void* h = dlopen(libs[i], RTLD_LAZY|RTLD_LOCAL|RTLD_NOLOAD);
    if (!h) h = dlopen(libs[i], RTLD_LAZY|RTLD_LOCAL);
    if (!h) continue;
    sym = dlsym(h, name);
    if (sym) return sym;
  }

  /* 3) 可选：遍历进程已加载 so（仅当显式开启且可用） */
#if defined(IRVM_HAVE_DL_ITERATE)
  IRVM_FindCtx ctx = { name, NULL };
  dl_iterate_phdr(irvm_phdr_cb, &ctx);
  if (ctx.sym) return ctx.sym;
#endif

  return NULL;
}

/* 旧接口：可指定库名（保留） */
int vm_link_dynamic(struct VMProc* P, const VMImportSpec* specs, int n){
  if (n<=0) return 0;
  P->imps.n = n;
  if (!P->imps.fns)   P->imps.fns=(HostThunk3*)calloc((size_t)n,sizeof(HostThunk3));
  if (!P->imps.ctx)   P->imps.ctx=(void**)calloc((size_t)n,sizeof(void*));
  if (!P->imps.names) P->imps.names=(const char**)calloc((size_t)n,sizeof(const char*));

  for (int i=0;i<n;i++){
    const VMImportSpec* s = &specs[i];
    void* sym = NULL;

    if (s->soname && s->soname[0]) {
      // 显式库名：正常 dlopen + dlsym
      void* handle = dlopen(s->soname, RTLD_LAZY|RTLD_LOCAL);
      if (!handle){
        fprintf(stderr,"dlopen %s fail: %s\n", s->soname, dlerror());
        P->trap=1; return -1;
      }
      sym = dlsym(handle, s->name);
    } else {
      // 无库名：直接在全局符号表找
      sym = dlsym(RTLD_DEFAULT, s->name);

      // 还找不到？再在常见系统库兜底枚举
      if (!sym){
#if defined(__ANDROID__)
        static const char* libs[] = {"libc.so","libm.so","libdl.so","liblog.so","libandroid.so", NULL};
#else
        static const char* libs[] = {
          "libc.so.6","libm.so.6","libdl.so.2","librt.so.1","libpthread.so.0",
          "libc.so","libm.so","libdl.so", NULL
        };
#endif
        for (int j=0; !sym && libs[j]; ++j){
          void* h = dlopen(libs[j], RTLD_LAZY|RTLD_LOCAL|RTLD_NOLOAD);
          if (!h) h = dlopen(libs[j], RTLD_LAZY|RTLD_LOCAL);
          if (!h) continue;
          sym = dlsym(h, s->name);
        }
      }
    }

    if (!sym){
      fprintf(stderr,"dlsym %s fail (no soname)\n", s->name);
      P->trap=1; return -1;
    }

    if (bind_one_ctx(P, sym, s->sig, s->import_id)!=0){ P->trap=1; return -1; }
    if (P->imps.names) P->imps.names[s->import_id]=s->name;
  }

  P->imps.call = vm_import_call_ffi;
  return 0;
}

/* 新接口：只给“名字+签名”，自动解析，无需手填地址/库名 */
int vm_link_auto(struct VMProc* P, const VMImportDecl* decls, int n){
  if (n<=0) return 0;
  P->imps.n = n;
  if (!P->imps.fns)   P->imps.fns=(HostThunk3*)calloc((size_t)n,sizeof(HostThunk3));
  if (!P->imps.ctx)   P->imps.ctx=(void**)calloc((size_t)n,sizeof(void*));
  if (!P->imps.names) P->imps.names=(const char**)calloc((size_t)n,sizeof(const char*));

  for (int i=0;i<n;i++){
    void* sym = try_resolve_symbol_auto(decls[i].name);
    if (!sym){ fprintf(stderr,"[IRVM] TRAP: auto-resolve %s failed\n", decls[i].name); P->trap=1; return -1; }
    if (bind_one_ctx(P, sym, decls[i].sig, /*slot=*/i)!=0){ P->trap=1; return -1; }
    if (P->imps.names) P->imps.names[i]=decls[i].name;
  }
  P->imps.call = vm_import_call_ffi;
  return 0;
}
