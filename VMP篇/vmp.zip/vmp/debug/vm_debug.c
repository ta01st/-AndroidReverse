// #include "../debug/vm_debug.h"
#include "../include/vm_debug.h"
// #include "../core/vm_types.h"
#include <stdio.h>
#include <string.h>

const char* ir_op_name(uint8_t op){
  switch(op){
    case I_ALLOCA: return "ALLOCA"; case I_LOAD: return "LOAD"; case I_STORE: return "STORE";
    case I_GEP: return "GEP";
    case I_ADD: return "ADD"; case I_SUB: return "SUB"; case I_MUL: return "MUL";
    case I_UDIV: return "UDIV"; case I_SDIV: return "SDIV"; case I_UREM: return "UREM"; case I_SREM: return "SREM";
    case I_AND: return "AND"; case I_OR: return "OR"; case I_XOR: return "XOR";
    case I_SHL: return "SHL"; case I_LSHR: return "LSHR"; case I_ASHR: return "ASHR";
    case I_ICMP: return "ICMP"; case I_SELECT: return "SELECT";
    case I_TRUNC: return "TRUNC"; case I_ZEXT: return "ZEXT"; case I_SEXT: return "SEXT";
    case I_BITCAST: return "BITCAST"; case I_PTRTOINT: return "PTR2I"; case I_INTTOPTR: return "I2PTR";
    case I_ICONST: return "ICONST";
    case I_BR: return "BR"; case I_BRCOND: return "BRCOND"; case I_RET: return "RET";
    case I_CALL_VM: return "CALL_VM"; case I_CALL_HOST: return "CALL_HOST";
    case I_HALT: return "HALT";
    default: return "OP?";
  }
}

static void fcat(char* o, size_t* k, size_t cap, const char* s){ size_t n=strlen(s); if (*k+n+1>=cap) return; memcpy(o+*k,s,n); *k+=n; o[*k]=0; }
static void fcati(char* o, size_t* k, size_t cap, int x){ char b[32]; snprintf(b,sizeof(b),"%d",x); fcat(o,k,cap,b); }
static void fcatu(char* o, size_t* k, size_t cap, unsigned x){ char b[32]; snprintf(b,sizeof(b),"%u",x); fcat(o,k,cap,b); }

void ir_disasm(const IRIns* I, char* out, size_t cap){
  size_t k=0; out[0]=0;
  fcat(out,&k,cap, ir_op_name(I->op)); fcat(out,&k,cap," ");
  if (I->dst!=0xFFFF){ fcat(out,&k,cap,"v"); fcatu(out,&k,cap,I->dst); fcat(out,&k,cap," <- "); }
  switch(I->op){
    case I_ALLOCA: fcat(out,&k,cap,"alloca size="); fcati(out,&k,cap,I->imm);
                   fcat(out,&k,cap," align="); fcati(out,&k,cap,I->aux); break;
    case I_LOAD: case I_STORE:
      fcat(out,&k,cap,I->op==I_LOAD?"load ":"store "); fcat(out,&k,cap,"ty="); fcati(out,&k,cap,I->ty);
      fcat(out,&k,cap," a=v"); fcatu(out,&k,cap,I->a); if (I->op==I_STORE){ fcat(out,&k,cap," b=v"); fcatu(out,&k,cap,I->b); }
      fcat(out,&k,cap," align="); fcati(out,&k,cap,I->imm); if (I->flags&FLG_VOL) fcat(out,&k,cap," vol"); break;
    case I_GEP: fcat(out,&k,cap,"base=v"); fcatu(out,&k,cap,I->a);
                fcat(out,&k,cap," idx=v"); fcatu(out,&k,cap,I->b);
                fcat(out,&k,cap," scale="); fcati(out,&k,cap,I->imm);
                fcat(out,&k,cap," off="); fcati(out,&k,cap,I->aux); break;
    case I_ADD: case I_SUB: case I_MUL: case I_AND: case I_OR: case I_XOR:
    case I_UDIV: case I_SDIV: case I_UREM: case I_SREM:
    case I_SHL: case I_LSHR: case I_ASHR:
      fcat(out,&k,cap,"ty="); fcati(out,&k,cap,I->ty); fcat(out,&k,cap," a=v"); fcatu(out,&k,cap,I->a); fcat(out,&k,cap," b=v"); fcatu(out,&k,cap,I->b);
      if (I->flags&(FLG_NSW|FLG_NUW|FLG_EXACT)){ fcat(out,&k,cap," ["); if(I->flags&FLG_NUW) fcat(out,&k,cap,"nuw "); if(I->flags&FLG_NSW) fcat(out,&k,cap,"nsw "); if(I->flags&FLG_EXACT) fcat(out,&k,cap,"exact"); fcat(out,&k,cap,"]"); } break;
    case I_ICMP: fcat(out,&k,cap,"pred="); fcati(out,&k,cap,I->imm); fcat(out,&k,cap," a=v"); fcatu(out,&k,cap,I->a); fcat(out,&k,cap," b=v"); fcatu(out,&k,cap,I->b); break;
    case I_SELECT: fcat(out,&k,cap,"cond=v"); fcatu(out,&k,cap,I->a); fcat(out,&k,cap," x=v"); fcatu(out,&k,cap,I->b); fcat(out,&k,cap," y=v"); fcatu(out,&k,cap,I->c); break;
    case I_TRUNC: case I_ZEXT: case I_SEXT: case I_BITCAST: case I_PTRTOINT: case I_INTTOPTR:
      fcat(out,&k,cap,"dst.ty="); fcati(out,&k,cap,I->ty); fcat(out,&k,cap," a=v"); fcatu(out,&k,cap,I->a); break;
    case I_ICONST: fcat(out,&k,cap,"ty="); fcati(out,&k,cap,I->ty); fcat(out,&k,cap," imm="); fcati(out,&k,cap,I->imm); break;
    case I_BR: fcat(out,&k,cap,"pc="); fcati(out,&k,cap,I->imm); break;
    case I_BRCOND: fcat(out,&k,cap,"cond=v"); fcatu(out,&k,cap,I->a); fcat(out,&k,cap," T="); fcati(out,&k,cap,I->imm); fcat(out,&k,cap," F="); fcati(out,&k,cap,I->aux); break;
    case I_RET: fcat(out,&k,cap,"v"); fcatu(out,&k,cap,I->a); break;
    case I_CALL_VM: case I_CALL_HOST: fcat(out,&k,cap,(I->op==I_CALL_VM)?"func_id=":"import_id="); fcati(out,&k,cap,I->imm); fcat(out,&k,cap," argc="); fcati(out,&k,cap,I->aux); break;
    default: break;
  }
}

void irvm_trace_stdout(struct VMProc* P, int pc, const IRIns* ins, void* user){
  (void)P; (void)user;
  char buf[256]; ir_disasm(ins, buf, sizeof(buf));
  fprintf(stderr,"[trace] pc=%d : %s\n", pc, buf);
}

int irvm_run_code(struct VMProc* P,
                  const IRIns* code, int ncode, int nslots, const char* name,
                  const uint64_t* argv, int argc,
                  uint64_t* ret_bits, IRType* ret_ty)
{
  VMFunc saved={ .code=code, .ncode=ncode, .nslots=nslots, .name=name?name:"<code>" };
  VMFunc* old=P->mod.funcs; int oldn=P->mod.nfuncs;
  P->mod.funcs=&saved; P->mod.nfuncs=1;
  int rc=irvm_run_func(P,0,argv,argc,ret_bits,ret_ty);
  P->mod.funcs=old; P->mod.nfuncs=oldn;
  return rc;
}
