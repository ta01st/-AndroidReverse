#pragma once
#include <stddef.h>

#include "vm_types.h"
#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

    typedef struct { const IRIns* code; int ncode; int nslots; const char* name; } VMFunc;

    struct VMProc;

    // 手写宿主桩（可选）
    typedef long long (*HostThunk3)(struct VMProc*, uint64_t* args, int argc);
    // 统一导入分发：解释器只调用这个
    typedef long long (*ImportCallFn)(struct VMProc*, int import_id, uint64_t* args, int argc);

    // —— 调试 Trace Hook ——
    // 由 debug 模块提供默认实现，你也可以替换成自定义的
    typedef void (*IRVMTraceHook)(struct VMProc* P, int pc, const IRIns* ins, void* user);

    typedef struct {
        HostThunk3*  fns;     // 可选：手写桩；若存在优先走 fns[id]
        void**       ctx;     // 预留：通用 FFI 上下文（本版本未用）
        const char** names;   // 调试名/签名
        int          n;
        ImportCallFn call;    // 必须设置：统一分发
    } VMImports;

    typedef struct VMProc {
        uint8_t* mem; size_t mem_size; size_t sp_global;
        struct { VMFunc* funcs; int nfuncs; } mod;
        VMImports imps;
        int trap;

        // —— 调试 —— //
        IRVMTraceHook trace_hook;
        void*         trace_user;
        int           trace_enabled;
    } VMProc;

    void vm_init(struct VMProc* P, uint8_t* mem, size_t memsz, VMFunc* funs, int nf);

    // 简便设置导入表（只设 fns/names/n，call 使用默认分发）
    void vm_set_imports(struct VMProc* P, HostThunk3* fns, const char** names, int n);

#ifdef __cplusplus
}
#endif
