#pragma once
#include <stdint.h>
#include <stddef.h>

#include "vm_types.h"
#include "vm_proc.h"
// 如果需要也可包含：#include "vm_import_resolve.h" 但头里不强制

#ifdef __cplusplus
extern "C" {
#endif

/* ====== 重定位描述（与 pass 输出保持一致） ====== */
typedef struct { int pc; const char* name; } IRVM_RelCallVM;
typedef struct { int pc; const char* name; const char* sig; } IRVM_RelCallHost;
typedef struct { int pc; const char* gbl;  int addend; } IRVM_RelIconstPtr;

/* ====== 函数粒度的打包 ======
 * code/nins/nslots/name 由 pass 导出
 * rcvm/rhost/riptr 也是 pass 导出
 */
typedef struct IRVM_FuncBlob {
  const IRIns*               code;
  int                        nins;
  int                        nslots;
  const char*                name;

  const IRVM_RelCallVM*      rcvm;   int rcvm_n;
  const IRVM_RelCallHost*    rhost;  int rhost_n;
  const IRVM_RelIconstPtr*   riptr;  int riptr_n;
} IRVM_FuncBlob;

/* ====== 模块级打包 ====== */
typedef struct IRVM_Blob {
  const IRVM_FuncBlob* funcs;
  int                  nfuncs;
} IRVM_Blob;

/* ====== 数据拷贝描述（例如字符串放入 VM 内存） ====== */
typedef struct IRVM_DataBlob {
  const char*  gbl;     /* 符号名（比如 ".str"） */
  uint32_t     vm_off;  /* 放在 VM 线性内存中的偏移 */
  const void*  data;    /* 源数据（可为 NULL，只做地址回填） */
  size_t       len;     /* 数据长度 */
} IRVM_DataBlob;

/* ====== （可选）便捷宏：手写或 pass 侧复用 ======
 * 仅当你要在手写代码里组装 blob 时使用。pass 侧也可以生成相同符号。
 */
#define IRVM_DECLARE_FUNC(name)                                          \
  extern const IRIns code_##name[];                                      \
  extern const int   code_##name##_nins;                                 \
  extern const int   code_##name##_nslots;                               \
  extern const IRVM_RelCallVM    rel_callvm_##name[];  extern const int rel_callvm_##name##_n; \
  extern const IRVM_RelCallHost  rel_callhost_##name[];extern const int rel_callhost_##name##_n; \
  extern const IRVM_RelIconstPtr rel_iconst_ptr_##name[];extern const int rel_iconst_ptr_##name##_n

#define IRVM_FUNC_BLOB(name)                                             \
  { code_##name, code_##name##_nins, code_##name##_nslots, #name,        \
    rel_callvm_##name, rel_callvm_##name##_n,                            \
    rel_callhost_##name, rel_callhost_##name##_n,                        \
    rel_iconst_ptr_##name, rel_iconst_ptr_##name##_n }

/* ====== 对外 API ====== */

/* 若工程未使用 weak 符号导出默认 blob/data，可在运行前手动设置 */
void      irvm_set_defaults(const IRVM_Blob* blob,
                            const IRVM_DataBlob* data, int data_n);

/* 取 VMProc（可用于打开/设置 trace 等） */
struct VMProc* irvm_get_proc(void);

/* 入口：按名调用（内部自动一次性初始化） */
uint64_t  irvm_entry_call(const char* func_name, const uint64_t* args, int argc);

#ifdef __cplusplus
}
#endif
