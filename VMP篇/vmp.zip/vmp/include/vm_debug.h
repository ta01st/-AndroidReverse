#pragma once
#include "vm_types.h"
#include "vm_proc.h"
#include <stddef.h>

#ifdef __cplusplus
extern "C" {
#endif

    const char* ir_op_name(uint8_t op);
    void ir_disasm(const IRIns* ins, char* out, size_t out_sz);

    static inline void irvm_trace_enable(struct VMProc* P, int on){ P->trace_enabled=on; }
    static inline void irvm_set_trace(struct VMProc* P, IRVMTraceHook hook, void* user){
        P->trace_hook=hook; P->trace_user=user;
    }
    void irvm_trace_stdout(struct VMProc* P, int pc, const IRIns* ins, void* user);

    int irvm_run_code(struct VMProc* P,
                      const IRIns* code, int ncode, int nslots, const char* name,
                      const uint64_t* argv, int argc,
                      uint64_t* ret_bits, IRType* ret_ty);

#ifdef __cplusplus
}
#endif
