#pragma once
#include "vm_proc.h"

#ifdef __cplusplus
extern "C" {
#endif

    // 仅当没有动态解析时的兜底：若 fns[id] 不存在则 TRAP
    long long vm_import_call_default(struct VMProc* P, int import_id, uint64_t* args, int argc);

#ifdef __cplusplus
}
#endif
