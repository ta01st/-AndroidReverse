#pragma once
#include "vm_types.h"
#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

    struct VMProc; // 前向声明

    // 解释器入口：执行模块中的第 fidx 个函数
    int irvm_run_func(struct VMProc* P, int fidx,
                      const uint64_t* argv, int argc,
                      uint64_t* ret_bits, IRType* ret_ty);

#ifdef __cplusplus
}
#endif



