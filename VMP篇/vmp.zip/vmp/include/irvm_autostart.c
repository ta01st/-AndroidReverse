#include "irvm_autostart.h"

#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <pthread.h>

#include "vm_core.h"
#include "vm_import_resolve.h"

/* ===== 本模块内部使用的元信息（可写副本 + 重定位） ===== */
typedef struct {
  IRIns*                 code;   /* 克隆后的可写指令流 */
  int                    nins;
  int                    nslots;
  const char*            name;

  const IRVM_RelCallVM*      rcvm;   int rcvm_n;
  const IRVM_RelCallHost*    rhost;  int rhost_n;
  const IRVM_RelIconstPtr*   riptr;  int riptr_n;
} IRVM_FuncMeta;

/* ===== 全局状态（仅此 TU 内可见） ===== */
static struct {
  VMProc            P;
  uint8_t*          mem;
  size_t            mem_size;

  VMFunc*           vfns;    /* VM 的对外函数表（按 VMFunc 结构） */
  IRVM_FuncMeta*    metas;   /* 元信息（带重定位） */
  int               nfuncs;
  int               owns_code;

  /* 默认（可能来自 weak 符号） */
  const IRVM_Blob*       def_blob;
  const IRVM_DataBlob*   def_data;
  int                    def_data_n;

  int               inited_ok;
} G;

/* ========== 小工具 ========== */
static IRIns* clone_code_rw(const IRIns* ro, int n) {
  IRIns* rw = (IRIns*)malloc((size_t)n * sizeof(IRIns));
  if (!rw) return NULL;
  memcpy(rw, ro, (size_t)n * sizeof(IRIns));
  return rw;
}

/* CALL_VM 回填：把 .imm 改成真实 func_id */
static int patch_callvm(IRIns* code, int nins, VMProc* P,
                        const IRVM_RelCallVM* rel, int nrel) {
  if (!rel || nrel <= 0) return 0;
  for (int i = 0; i < nrel; ++i) {
    int pc = rel[i].pc;
    if (pc < 0 || pc >= nins) { fprintf(stderr,"[irvm] rel_callvm bad pc=%d\n", pc); return -1; }
    if (code[pc].op != I_CALL_VM) { fprintf(stderr,"[irvm] rel_callvm pc=%d not CALL_VM\n", pc); return -1; }
    /* 查 func_id */
    int id = -1;
    for (int j = 0; j < P->mod.nfuncs; ++j) {
      const char* nm = P->mod.funcs[j].name ? P->mod.funcs[j].name : "";
      if (strcmp(nm, rel[i].name) == 0) { id = j; break; }
    }
    if (id < 0) { fprintf(stderr,"[irvm] rel_callvm func '%s' not found\n", rel[i].name); return -1; }
    code[pc].imm = id;
  }
  return 0;
}

/* ICONST(ptr) 回填 + 数据拷贝 */
static int patch_iconst(IRIns* code, int nins, VMProc* P,
                        const IRVM_RelIconstPtr* rel, int nrel,
                        const IRVM_DataBlob* blobs, int nblobs) {
  if (!rel || nrel <= 0) return 0;
  for (int i = 0; i < nrel; ++i) {
    int pc = rel[i].pc;
    if (pc < 0 || pc >= nins) { fprintf(stderr,"[irvm] rel_iconst bad pc=%d\n", pc); return -1; }
    if (code[pc].op != I_ICONST || code[pc].ty != TY_PTR) {
      fprintf(stderr,"[irvm] rel_iconst pc=%d not ICONST PTR\n", pc); return -1;
    }
    int bi = -1;
    for (int b = 0; b < nblobs; ++b) {
      if (strcmp(blobs[b].gbl, rel[i].gbl) == 0) { bi = b; break; }
    }
    if (bi < 0) { fprintf(stderr,"[irvm] data blob for %s not provided\n", rel[i].gbl); return -1; }
    if (blobs[bi].data && blobs[bi].len) {
      if ((size_t)blobs[bi].vm_off + blobs[bi].len > P->mem_size) {
        fprintf(stderr,"[irvm] data blob OOB copy for %s\n", rel[i].gbl); return -1;
      }
      memcpy(P->mem + blobs[bi].vm_off, blobs[bi].data, blobs[bi].len);
    }
    code[pc].imm = (int)(blobs[bi].vm_off + (uint32_t)rel[i].addend);
  }
  return 0;
}

/* 收集去重的导入声明，并调用 vm_link_auto 自动解析符号 */
static int link_imports_all(void) {
  int cap = 16, cnt = 0;
  VMImportDecl* uniq = (VMImportDecl*)malloc((size_t)cap * sizeof(VMImportDecl));
  if (!uniq) return -1;

  for (int i = 0; i < G.nfuncs; ++i) {
    for (int j = 0; j < G.metas[i].rhost_n; ++j) {
      const char* n = G.metas[i].rhost[j].name;
      const char* s = G.metas[i].rhost[j].sig;
      int dup = 0;
      for (int k = 0; k < cnt; ++k) {
        if (!strcmp(uniq[k].name, n) && !strcmp(uniq[k].sig, s)) { dup = 1; break; }
      }
      if (dup) continue;
      if (cnt >= cap) {
        cap *= 2;
        uniq = (VMImportDecl*)realloc(uniq, (size_t)cap * sizeof(VMImportDecl));
        if (!uniq) return -1;
      }
      uniq[cnt].name = n;
      uniq[cnt].sig  = s;
      cnt++;
    }
  }

  int rc = 0;
  if (cnt > 0) rc = vm_link_auto(&G.P, uniq, cnt);
  free(uniq);
  return rc;
}

/* 把 blob 装载为可写副本并填充 P.mod.funcs */
static int load_blob(const IRVM_Blob* blob) {
  if (!blob || blob->nfuncs <= 0) return -1;

  G.vfns  = (VMFunc*)calloc((size_t)blob->nfuncs, sizeof(VMFunc));
  G.metas = (IRVM_FuncMeta*)calloc((size_t)blob->nfuncs, sizeof(IRVM_FuncMeta));
  if (!G.vfns || !G.metas) return -1;

  G.nfuncs    = blob->nfuncs;
  G.owns_code = 1;

  for (int i = 0; i < blob->nfuncs; ++i) {
    const IRVM_FuncBlob* FB = &blob->funcs[i];
    IRIns* rw = clone_code_rw(FB->code, FB->nins);
    if (!rw) return -1;

    G.metas[i].code   = rw;
    G.metas[i].nins   = FB->nins;
    G.metas[i].nslots = FB->nslots;
    G.metas[i].name   = FB->name;

    G.metas[i].rcvm   = FB->rcvm;   G.metas[i].rcvm_n   = FB->rcvm_n;
    G.metas[i].rhost  = FB->rhost;  G.metas[i].rhost_n  = FB->rhost_n;
    G.metas[i].riptr  = FB->riptr;  G.metas[i].riptr_n  = FB->riptr_n;

    /* 注意：VMFunc 的字段名是 ncode（不是 nins）*/
    G.vfns[i].code   = rw;
    G.vfns[i].ncode  = FB->nins;
    G.vfns[i].nslots = FB->nslots;
    G.vfns[i].name   = FB->name;
  }

  G.P.mod.funcs  = G.vfns;
  G.P.mod.nfuncs = G.nfuncs;
  return 0;
}

/* 对所有函数做回填（CALL_VM / ICONST(ptr)） */
static int patch_all(void) {
  for (int i = 0; i < G.nfuncs; ++i) {
    if (patch_callvm(G.metas[i].code, G.metas[i].nins, &G.P, G.metas[i].rcvm,  G.metas[i].rcvm_n) != 0)
      return -1;
    if (G.def_data && G.def_data_n > 0) {
      if (patch_iconst(G.metas[i].code, G.metas[i].nins, &G.P,
                       G.metas[i].riptr, G.metas[i].riptr_n,
                       G.def_data, G.def_data_n) != 0)
        return -1;
    }
  }
  return 0;
}

/* ====== 对外：可手动设置默认 blob/data（若未用 weak 符号） ====== */
void irvm_set_defaults(const IRVM_Blob* blob, const IRVM_DataBlob* data, int data_n) {
  G.def_blob   = blob;
  G.def_data   = data;
  G.def_data_n = data_n;
}

/* ====== 一次性初始化（自动拾取 weak 符号） ====== */
static pthread_once_t g_once = PTHREAD_ONCE_INIT;

static void do_init_once(void) {
  /* 1) 分配 VM 线性内存并初始化 */
  size_t memsz = 64 * 1024;      /* 你也可以改大并做成 setter */
  G.mem = (uint8_t*)malloc(memsz);
  if (!G.mem) return;
  G.mem_size = memsz;

  vm_init(&G.P, G.mem, G.mem_size, NULL, 0);
  /* 如果你有默认分发，也可在此设：vm_set_imports(&G.P, NULL, NULL, 0); */

  /* 2) 如果外面没手动 irvm_set_defaults，则尝试用 weak 符号 */
  if (!G.def_blob) {
    __attribute__((weak)) extern const IRVM_Blob      irvm_default_blob;
    __attribute__((weak)) extern const IRVM_DataBlob  irvm_default_data[];
    __attribute__((weak)) extern const int            irvm_default_data_n;
    if (&irvm_default_blob)   G.def_blob   = &irvm_default_blob;
    if (&irvm_default_data)   G.def_data   = irvm_default_data;
    if (&irvm_default_data_n) G.def_data_n = irvm_default_data_n;
  }

  __attribute__((weak)) extern const IRVM_FuncBlob __start_irvm_funcs[];
  __attribute__((weak)) extern const IRVM_FuncBlob __stop_irvm_funcs[];
  if (!G.def_blob && &__start_irvm_funcs && &__stop_irvm_funcs) {
    static IRVM_Blob s_blob_from_section;
    size_t cnt = (size_t)(__stop_irvm_funcs - __start_irvm_funcs);
    if (cnt > 0) {
      s_blob_from_section.funcs  = __start_irvm_funcs;
      s_blob_from_section.nfuncs = (int)cnt;
      G.def_blob = &s_blob_from_section;
    }
  }

  if (!G.def_blob) { fprintf(stderr,"[irvm] no default blob\n"); return; }

  /* 3) 装载 blob、动态解析导入、回填重定位 */
  if (load_blob(G.def_blob)   != 0) { fprintf(stderr,"[irvm] load blob fail\n"); return; }
  if (link_imports_all()      != 0) { fprintf(stderr,"[irvm] link imports fail\n"); return; }
  if (patch_all()             != 0) { fprintf(stderr,"[irvm] patch fail\n"); return; }

  G.inited_ok = 1;
}

/* ====== 对外 API ====== */
VMProc* irvm_get_proc(void) { return &G.P; }

uint64_t irvm_entry_call(const char* func_name, const uint64_t* args, int argc) {
  (void)pthread_once(&g_once, do_init_once);
  if (!G.inited_ok) { fprintf(stderr,"[irvm] init not ok\n"); return 0; }

  /* 查函数 id */
  int id = -1;
  for (int i = 0; i < G.P.mod.nfuncs; ++i) {
    const char* nm = G.P.mod.funcs[i].name ? G.P.mod.funcs[i].name : "";
    if (strcmp(nm, func_name) == 0) { id = i; break; }
  }
  if (id < 0) { fprintf(stderr,"[irvm] func %s not found\n", func_name); return 0; }

  uint64_t rbits = 0;
  IRType   rty   = TY_I64;
  if (irvm_run_func(&G.P, id, args, argc, &rbits, &rty) != 0) {
    fprintf(stderr,"[irvm] run %s trap\n", func_name);
    return 0;
  }
  return rbits;
}
