#pragma once
#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

typedef enum { TY_VOID=0, TY_I1, TY_I8, TY_I16, TY_I32, TY_I64, TY_PTR } IRType;

enum { FLG_NSW=1u<<0, FLG_NUW=1u<<1, FLG_EXACT=1u<<2, FLG_VOL=1u<<3 };

typedef enum {
  I_ALLOCA, I_LOAD, I_STORE, I_GEP,
  I_ADD, I_SUB, I_MUL, I_UDIV, I_SDIV, I_UREM, I_SREM,
  I_AND, I_OR, I_XOR, I_SHL, I_LSHR, I_ASHR,
  I_ICMP, I_SELECT,
  I_TRUNC, I_ZEXT, I_SEXT, I_BITCAST, I_PTRTOINT, I_INTTOPTR,
  I_ICONST,
  I_BR, I_BRCOND, I_RET,
  I_CALL_VM, I_CALL_HOST,
  I_HALT
} IROp;

typedef struct {
  uint8_t  op, ty, flags, pad;
  uint16_t dst, a, b, c, d, e, f;
  int32_t  imm, aux;
} IRIns;

#ifdef __cplusplus
}
#endif
