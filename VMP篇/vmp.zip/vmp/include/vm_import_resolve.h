#pragma once
#include "vm_proc.h"

#ifdef __cplusplus
extern "C" {
#endif

    // 旧接口（保留）：可带 soname/version
    typedef struct {
        const char* name;
        const char* soname;   // 可空
        const char* version;  // 可空（glibc）
        const char* sig;      // 例: "i32(ptr[in vm], i32)"
        uint32_t    import_id;
        uint32_t    flags;
    } VMImportSpec;

    // ★ 新接口：仅“名字 + 签名”，其余自动解析
    typedef struct {
        const char* name;     // 符号名，如 "printf" / "__android_log_write"
        const char* sig;      // 我们的简易签名语法（与之前一致）
    } VMImportDecl;

    // 手工/指定库解析（保留）
    int vm_link_dynamic(struct VMProc* P, const VMImportSpec* specs, int n);

    // ★ 自动解析：无需填写 so/地址
    int vm_link_auto(struct VMProc* P, const VMImportDecl* decls, int n);

    // 分发（无变化）
    long long vm_import_call_ffi(struct VMProc* P, int import_id, uint64_t* args, int argc);

#ifdef __cplusplus
}
#endif
