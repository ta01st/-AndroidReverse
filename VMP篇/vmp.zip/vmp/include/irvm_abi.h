#pragma once
#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

/* ====== 必须与 pass 端 irvm_lower.h 的枚举/布局一一对应 ====== */
typedef enum {
  TY_VOID=0, TY_I1, TY_I8, TY_I16, TY_I32, TY_I64, TY_PTR
} IRType;

typedef enum {
  I_ALLOCA, I_LOAD, I_STORE, I_GEP,
  I_ADD, I_SUB, I_MUL, I_UDIV, I_SDIV, I_UREM, I_SREM,
  I_AND, I_OR, I_XOR, I_SHL, I_LSHR, I_ASHR,
  I_ICMP, I_SELECT,
  I_TRUNC, I_ZEXT, I_SEXT, I_BITCAST, I_PTRTOINT, I_INTTOPTR,
  I_ICONST,
  I_BR, I_BRCOND, I_RET,
  I_CALL_VM, I_CALL_HOST,
  I_HALT
} IROp;

enum { FLG_NSW=1u<<0, FLG_NUW=1u<<1, FLG_EXACT=1u<<2, FLG_VOL=1u<<3 };

/* 与 pass 端 IRInsBin 完全一致（按 1 字节对齐） */
#pragma pack(push,1)
typedef struct {
  uint8_t  op, ty, flags, pad;
  uint16_t dst, a, b, c, d, e, f;
  int32_t  imm, aux;
} IRIns;
#pragma pack(pop)

/* ====== 重定位表：名字和字段顺序要与 pass emit 的一致 ====== */
typedef struct { int pc; const char* name; } IRVM_RelCallVM;
typedef struct { int pc; const char* name; const char* sig; } IRVM_RelCallHost;
typedef struct { int pc; const char* gbl; int addend; } IRVM_RelIconstPtr;

/* ====== pass 每个函数会生成一个 FuncBlob（指针一律视为 i8* 导出） ====== */
typedef struct {
  const uint8_t*           code;   /* = code_*_bytes 的 &bytes[0] */
  int                      nins;
  int                      nslots;
  const char*              name;
  const IRVM_RelCallVM*    rcvm;   int rcvm_n;
  const IRVM_RelCallHost*  rhost;  int rhost_n;
  const IRVM_RelIconstPtr* riptr;  int riptr_n;
} IRVM_FuncBlob;

/* 一个 Blob 可以包含多个函数（pass 目前每次只塞 1 个也没问题） */
typedef struct {
  const IRVM_FuncBlob* funcs;
  int                  nfuncs;
} IRVM_Blob;

/* 可选：初始化把全局常量预拷到 VM 线性内存 */
typedef struct {
  const char* gbl;      /* 符号名（与 rel_iconst_ptr 里一致） */
  uint32_t    vm_off;   /* 拷贝到 VM 线性内存的偏移 */
  const void* data;     /* 要拷贝的数据（可为 NULL） */
  uint32_t    len;      /* 数据长度（0 表示不拷贝只修 IMM） */
} IRVM_DataBlob;

/* ====== 对外入口（pass 桩会直接调用它） ====== */
uint64_t irvm_entry_call(const char* func_name,
                         const uint64_t* args, int argc);

/* 初始化默认的 blob / data（若不使用弱符号自动拾取时可手动设置） */
void irvm_set_defaults(const IRVM_Blob* blob,
                       const IRVM_DataBlob* data, int data_n);

#ifdef __cplusplus
}
#endif
