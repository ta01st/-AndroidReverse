#include <stdio.h>
#include <string.h>
#include <stdint.h>
#include <stdlib.h>

#include "vm_types.h"
#include "include/vm_core.h"
#include "include/vm_proc.h"
#include "include/vm_import_resolve.h"
#include "include/vm_debug.h"

/* ===== 你的 pass 输出（保持不变，注意它们是 const）===== */


unsigned long vm(uint8_t * code,unsigned long * agrs,int nums) {
  printf("hello this is vm");
  return 0;
}

int main(void){

  return 0;
}
