#include "../include/vm_core.h"
#include "../include/vm_proc.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <limits.h>

/* 工具函数 */
static inline int ty_bits(IRType t){
  switch(t){ case TY_I1: return 1; case TY_I8: return 8; case TY_I16: return 16;
             case TY_I32: return 32; case TY_I64: return 64; case TY_PTR: return 64; default: return 0; }
}
static inline int ty_align(IRType t){ int b=ty_bits(t); return b<=8?1:b<=16?2:b<=32?4:8; }
static inline uint64_t mask_n(int n){ return (n>=64)?~0ull:((1ull<<n)-1ull); }
static inline unsigned __int128 mask_128(int n){ return (n>=128)?~( (unsigned __int128)0 ):((((unsigned __int128)1)<<n)-1); }
static inline uint64_t zext_to64(unsigned __int128 x, int n){ return (uint64_t)(x & mask_128(n)); }
static inline long long  sext_to64(unsigned __int128 x, int n){ unsigned __int128 m=((unsigned __int128)1<<(n-1)); unsigned __int128 v=x & mask_128(n); return (long long)((v^m)-m); }
static inline int check_align(uint64_t addr, int al){ return (addr % (uint64_t)al)==0; }
static inline int check_oob(struct VMProc* P, uint64_t addr, size_t len){ return addr+len <= P->mem_size; }
static inline void vm_trap(struct VMProc* P, const char* why){ P->trap=1; fprintf(stderr,"[IRVM] TRAP: %s\n", why); }

/* 溢出检查 */
static inline int ovf_add_u(uint64_t a,uint64_t b,int w){ uint64_t r=(a&mask_n(w))+(b&mask_n(w)); return (r & mask_n(w)) < (a & mask_n(w)); }
static inline int ovf_sub_u(uint64_t a,uint64_t b,int w){ return (a & mask_n(w)) < (b & mask_n(w)); }
static inline int ovf_mul_u(uint64_t a,uint64_t b,int w){ unsigned __int128 r=(unsigned __int128)(a&mask_n(w))*(unsigned __int128)(b&mask_n(w)); return r>mask_128(w); }
static inline int ovf_add_s(long long a,long long b,int w){ long long r=a+b; long long min=-(1ll<<(w-1)), max=(1ll<<(w-1))-1; return r<min||r>max; }
static inline int ovf_sub_s(long long a,long long b,int w){ long long r=a-b; long long min=-(1ll<<(w-1)), max=(1ll<<(w-1))-1; return r<min||r>max; }
static inline int ovf_mul_s(long long a,long long b,int w){ __int128 r=(__int128)a*(__int128)b; __int128 min=-(((__int128)1)<<(w-1)), max=(((__int128)1)<<(w-1))-1; return r<min||r>max; }

/* 槽 */
typedef struct { unsigned __int128 bits; IRType ty; } Slot;

int irvm_run_func(struct VMProc* P, int fidx, const uint64_t* argv, int argc,
                  uint64_t* ret_bits, IRType* ret_ty){
  if (fidx<0 || fidx>=P->mod.nfuncs){ vm_trap(P,"bad func id"); return -1; }
  const VMFunc* F=&P->mod.funcs[fidx];

  size_t frame_sz=4096;
  if (P->sp_global + frame_sz > P->mem_size){ vm_trap(P,"stack OOM"); return -1; }
  Slot* slots=(Slot*)calloc((size_t)F->nslots,sizeof(Slot));
  size_t frame_base=P->sp_global, frame_sp=0;
  P->sp_global += frame_sz;

  for (int i=0;i<argc && i<F->nslots;i++){ slots[i].bits=argv[i]; slots[i].ty=TY_I64; }

  int pc=0;
  while (pc < F->ncode && !P->trap){
    IRIns I = F->code[pc++];

    if (P->trace_enabled && P->trace_hook) P->trace_hook(P, pc-1, &I, P->trace_user);

    int w=ty_bits((IRType)I.ty);

    switch(I.op){
      case I_ALLOCA: {
        int sz=I.imm, al=I.aux?I.aux:8;
        frame_sp=(frame_sp+(size_t)(al-1)) & ~((size_t)al-1);
        if (frame_base+frame_sp+(size_t)sz > P->mem_size){ vm_trap(P,"alloca OOB"); break; }
        uint64_t addr=(uint64_t)(frame_base+frame_sp); frame_sp+=(size_t)sz;
        slots[I.dst].bits=addr; slots[I.dst].ty=TY_PTR; break; }

      case I_LOAD: {
        uint64_t addr=(uint64_t)slots[I.a].bits;
        int al=I.imm?I.imm:ty_align((IRType)I.ty);
        size_t sz=(size_t)((w+7)/8);
        if (!check_align(addr,al)){ vm_trap(P,"load align"); break; }
        if (!check_oob(P,addr,sz)){ vm_trap(P,"load OOB"); break; }
        unsigned __int128 v=0; memcpy(&v,P->mem+addr,sz);
        slots[I.dst].bits=v & mask_128(w); slots[I.dst].ty=(IRType)I.ty; break; }

      case I_STORE: {
        uint64_t addr=(uint64_t)slots[I.a].bits;
        uint64_t val =(uint64_t)slots[I.b].bits;
        int al=I.imm?I.imm:ty_align((IRType)I.ty);
        size_t sz=(size_t)((w+7)/8);
        if (!check_align(addr,al)){ vm_trap(P,"store align"); break; }
        if (!check_oob(P,addr,sz)){ vm_trap(P,"store OOB"); break; }
        uint64_t x=val & mask_n(w); memcpy(P->mem+addr,&x,sz); break; }

      case I_GEP: {
        uint64_t base=(uint64_t)slots[I.a].bits;
        long long idx=(long long)slots[I.b].bits;
        long long scale=(long long)I.imm, off=(long long)I.aux;
        uint64_t addr=(uint64_t)((long long)base + idx*scale + off);
        slots[I.dst].bits=addr; slots[I.dst].ty=TY_PTR; break; }

      case I_ADD: case I_SUB: case I_MUL: {
        uint64_t au=zext_to64(slots[I.a].bits,w), bu=zext_to64(slots[I.b].bits,w);
        long long as=sext_to64(slots[I.a].bits,w), bs=sext_to64(slots[I.b].bits,w);
        uint64_t rr=0;
        if (I.op==I_ADD){
          if ((I.flags&FLG_NUW)&&ovf_add_u(au,bu,w)){ vm_trap(P,"add nuw"); break; }
          if ((I.flags&FLG_NSW)&&ovf_add_s(as,bs,w)){ vm_trap(P,"add nsw"); break; }
          rr=(au+bu)&mask_n(w);
        } else if (I.op==I_SUB){
          if ((I.flags&FLG_NUW)&&ovf_sub_u(au,bu,w)){ vm_trap(P,"sub nuw"); break; }
          if ((I.flags&FLG_NSW)&&ovf_sub_s(as,bs,w)){ vm_trap(P,"sub nsw"); break; }
          rr=(au-bu)&mask_n(w);
        } else {
          if ((I.flags&FLG_NUW)&&ovf_mul_u(au,bu,w)){ vm_trap(P,"mul nuw"); break; }
          if ((I.flags&FLG_NSW)&&ovf_mul_s(as,bs,w)){ vm_trap(P,"mul nsw"); break; }
          rr=(uint64_t)((unsigned __int128)au*bu & mask_128(w));
        }
        slots[I.dst].bits=rr; slots[I.dst].ty=(IRType)I.ty; break; }

      case I_UDIV: case I_SDIV: case I_UREM: case I_SREM: {
        uint64_t au=zext_to64(slots[I.a].bits,w), bu=zext_to64(slots[I.b].bits,w);
        long long as=sext_to64(slots[I.a].bits,w), bs=sext_to64(slots[I.b].bits,w);
        if (bu==0){ vm_trap(P,"div 0"); break; }
        if (I.op==I_SDIV && as==(-(1ll<<(w-1))) && bs==-1){ vm_trap(P,"sdiv ovf"); break; }
        uint64_t r=0;
        if (I.op==I_UDIV) r=(au/bu)&mask_n(w);
        else if (I.op==I_SDIV) r=(uint64_t)((long long)as/(long long)bs)&mask_n(w);
        else if (I.op==I_UREM) r=(au%bu)&mask_n(w);
        else r=(uint64_t)((long long)as%(long long)bs)&mask_n(w);
        if (I.flags&FLG_EXACT){
          if (I.op==I_UDIV && (au%bu)!=0){ vm_trap(P,"udiv !exact"); break; }
          if (I.op==I_SDIV && ((long long)as%(long long)bs)!=0){ vm_trap(P,"sdiv !exact"); break; }
        }
        slots[I.dst].bits=r; slots[I.dst].ty=(IRType)I.ty; break; }

      case I_AND: case I_OR: case I_XOR: {
        uint64_t au=zext_to64(slots[I.a].bits,w), bu=zext_to64(slots[I.b].bits,w), r=0;
        if (I.op==I_AND) r=au&bu; else if (I.op==I_OR) r=au|bu; else r=au^bu;
        slots[I.dst].bits=r & mask_n(w); slots[I.dst].ty=(IRType)I.ty; break; }

      case I_SHL: case I_LSHR: case I_ASHR: {
        uint64_t au=zext_to64(slots[I.a].bits,w);
        uint64_t sh=(uint64_t)slots[I.b].bits & 63ull; if ((int)sh>=w) sh=(uint64_t)w;
        uint64_t r=0;
        if (I.op==I_SHL){
          if ((I.flags&FLG_NUW)&&((au<<sh)&~mask_n(w))){ vm_trap(P,"shl nuw"); break; }
          if ((I.flags&FLG_NSW)&&sh>0){
            long long before=sext_to64(au,w), after=sext_to64((au<<sh)&mask_n(w),w);
            if ((before<0)!=(after<0)){ vm_trap(P,"shl nsw"); break; }
          }
          r=(au<<sh)&mask_n(w);
        } else if (I.op==I_LSHR){
          if ((I.flags&FLG_EXACT) && ((au & ((1ull<<sh)-1ull))!=0)){ vm_trap(P,"lshr !exact"); break; }
          r=(au>>sh)&mask_n(w);
        } else {
          long long as=sext_to64(au,w);
          if ((I.flags&FLG_EXACT) && ((au & ((1ull<<sh)-1ull))!=0)){ vm_trap(P,"ashr !exact"); break; }
          r=(uint64_t)((long long)as>>sh)&mask_n(w);
        }
        slots[I.dst].bits=r; slots[I.dst].ty=(IRType)I.ty; break; }

      case I_ICMP: {
        uint64_t au=zext_to64(slots[I.a].bits,w), bu=zext_to64(slots[I.b].bits,w);
        long long as=sext_to64(slots[I.a].bits,w), bs=sext_to64(slots[I.b].bits,w);
        int r=0;
        switch(I.imm){
          case 0: r=(au==bu); break; case 1: r=(au!=bu); break;
          case 2: r=(au> bu); break; case 3: r=(au>=bu); break;
          case 4: r=(au< bu); break; case 5: r=(au<=bu); break;
          case 6: r=(as> bs); break; case 7: r=(as>=bs); break;
          case 8: r=(as< bs); break; case 9: r=(as<=bs); break;
          default: vm_trap(P,"bad icmp"); break;
        }
        slots[I.dst].bits=(uint64_t)(r?1:0); slots[I.dst].ty=TY_I1; break; }

      case I_SELECT: {
        uint64_t cond=(uint64_t)slots[I.a].bits & 1ull;
        Slot src = cond? slots[I.b] : slots[I.c];
        int tw=ty_bits((IRType)I.ty);
        src.bits &= mask_128(tw); src.ty=(IRType)I.ty;
        slots[I.dst]=src; break; }

      case I_TRUNC: { int tw=w; slots[I.dst].bits=slots[I.a].bits & mask_128(tw); slots[I.dst].ty=(IRType)I.ty; break; }
      case I_ZEXT:  { int sw=ty_bits(slots[I.a].ty); uint64_t v=zext_to64(slots[I.a].bits,sw); slots[I.dst].bits=(unsigned __int128)(v & mask_n(w)); slots[I.dst].ty=(IRType)I.ty; break; }
      case I_SEXT:  { int sw=ty_bits(slots[I.a].ty); long long v=sext_to64(slots[I.a].bits,sw); slots[I.dst].bits=(unsigned __int128)((uint64_t)v & mask_n(w)); slots[I.dst].ty=(IRType)I.ty; break; }
      case I_BITCAST:{ slots[I.dst].bits=slots[I.a].bits; slots[I.dst].ty=(IRType)I.ty; break; }
      case I_PTRTOINT:{ uint64_t p=(uint64_t)slots[I.a].bits; slots[I.dst].bits=(unsigned __int128)(p & mask_n(w)); slots[I.dst].ty=(IRType)I.ty; break; }
      case I_INTTOPTR:{ uint64_t v=zext_to64(slots[I.a].bits,w); slots[I.dst].bits=(unsigned __int128)v; slots[I.dst].ty=TY_PTR; break; }

      case I_ICONST: {
        uint64_t v=(uint64_t)(uint32_t)I.imm; int tw=ty_bits((IRType)I.ty);
        slots[I.dst].bits=(unsigned __int128)(v & mask_n(tw)); slots[I.dst].ty=(IRType)I.ty; break; }

      case I_BR:     pc=I.imm; break;
      case I_BRCOND: { uint64_t c=(uint64_t)slots[I.a].bits & 1ull; pc = c? I.imm : I.aux; break; }
      case I_RET:    { if (ret_bits) *ret_bits=(uint64_t)slots[I.a].bits; if (ret_ty) *ret_ty=slots[I.a].ty; goto DONE; }

      case I_CALL_VM: {
        int callee=I.imm, n=I.aux; if (n<0)n=0; if (n>6)n=6;
        uint64_t av[6]={ slots[I.a].bits, slots[I.b].bits, slots[I.c].bits, slots[I.d].bits, slots[I.e].bits, slots[I.f].bits };
        uint64_t rbits=0; IRType rty=TY_I64;
        if (irvm_run_func(P, callee, av, n, &rbits, &rty)!=0) break;
        if (I.dst!=0xFFFF){ slots[I.dst].bits=rbits; slots[I.dst].ty=rty; }
        break; }

      case I_CALL_HOST: {
        int id=I.imm, n=I.aux; if (n<0)n=0; if (n>6)n=6;
        uint64_t av[6]={ slots[I.a].bits, slots[I.b].bits, slots[I.c].bits, slots[I.d].bits, slots[I.e].bits, slots[I.f].bits };
        long long rr = P->imps.call(P, id, av, n);
        if (P->trap) break;
        if (I.dst!=0xFFFF){ slots[I.dst].bits=(uint64_t)rr; slots[I.dst].ty=(IRType)I.ty; }
        break; }

      case I_HALT: goto DONE;
      default: vm_trap(P,"bad opcode"); break;
    }
  }

DONE:
  free(slots);
  P->sp_global -= 4096;
  return P->trap? -1:0;
}
